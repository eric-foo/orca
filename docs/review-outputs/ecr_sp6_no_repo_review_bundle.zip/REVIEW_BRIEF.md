# ECR SP-6 source-visibility deriver — adversarial code review (no-repo, de-correlated, advisory)

You are an **independent adversarial code reviewer**. You do **not** have repository
access; every file you need is in this bundle. Review **only** the bundled files.
Your output is **advisory decision-input only** — the home author adjudicates what is
kept. Nothing here is a readiness, validation, scoring, or deployment claim.

## De-correlation (a who-constraint, not a quality claim)

This artifact was authored by an Anthropic Opus model. For the review to add
de-correlation value, **you must be a different vendor/family from the author.**
If you are an Anthropic model, say so up front and note the reduced independence —
do not silently proceed as if de-correlated.

## No-repo working conditions

You have **no repository and no execution environment**: you cannot run the tests, a
Python interpreter, or any tooling, and you cannot fetch any file that is not in this
bundle. Reason **statically** from the bundled source. For the false-pass check (c)
below, construct the mutation and argue it by **reading**
`test_ecr_source_visibility_deriver.py`, not by running it. If your analysis needs a
file that is not in the bundle, **say so explicitly** rather than guessing — do not
assume the contents of anything you cannot see.

## What SP-6 is (orientation only)

SP-6 is the fourth "source-side subpredicate" deriver in an Evidence-Candidate-Record
(ECR) layer. It is a **pure function** over an already-validated producer packet
(`SourceCapturePacket`) that emits **exactly one per-packet posture** grading whether
the source's relevant state was visible **before a decision cutoff**. No I/O, no input
mutation, no downstream binding. A separate **frozen** conductor (NOT in this bundle,
NOT under review) will eventually read these postures — so this code must make **no**
readiness claim about that conductor, which stays frozen.

The other three rows (SP-1 identity, SP-2 inspectability, SP-3 timing) already exist
and are shown only as surrounding context in `models.py` / `deriver.py`. **Review SP-6
only**; treat SP-1/2/3 as fixed context.

## The contract SP-6 must faithfully realize (check fidelity against THIS)

Inputs the deriver reads from the packet:

- **A = `packet.archive_history_posture`** — a `VisibleFact`. On `status == KNOWN`,
  its `value` is closed to `{archived, attempt_failed}`. Otherwise its `status` is one
  of `{UNKNOWN_WITH_REASON, NOT_ATTEMPTED, NOT_APPLICABLE}`. (Packet-level, conservative.)
- **D = the archive-body slice's `timing.cutoff_posture`**, consumed strictly as a
  **CLASS** (the `KNOWN` value in `{pre_cutoff, post_cutoff, mixed, unknown}`). Per the
  recorded **641cf15 amendment**, D is **never** a timestamp: the producer never persists
  the cutoff instant (the archive selector applies a `<= cutoff` filter in memory and
  discards it), so a posture-class is the only honest binding. The archive-body slice is
  identified by `slice_id == "archive_snapshot_body"`.
- **C = current-body presence** — any **non-archive** slice that references ≥1 preserved
  file. Archive slice_ids = `{archive_snapshot_body, archive_availability}`.

Ratified closed **value** set (8): `archive_corroborated`, `archive_only`,
`archive_diverged`, `current_capture_only`, `archive_post_cutoff_only`, `attempt_failed`,
`not_attempted`, `not_applicable`.

Ratified closed **residual** set (6): `RESIDUAL_ARCHIVE_POST_CUTOFF_WITH_CURRENT`,
`RESIDUAL_COMPARISON_NOT_RECORDED`, `RESIDUAL_ARCHIVE_DATE_UNKNOWN`,
`RESIDUAL_ARCHIVE_POSTURE_UNKNOWN`, `RESIDUAL_NO_VISIBILITY_BASIS`,
`RESIDUAL_SLICE_DIVERGENT_VISIBILITY`.

**Decision C (clears):** the posture clears source-visibility **iff** its value ∈
`{archive_only, not_applicable}`.

**Intended decision table (residual-first; code precedence is
archived → attempt_failed → unknown_with_reason → current_present → not_attempted → else):**

| A | D | current? | result | clears? |
|---|---|---|---|---|
| archived | pre_cutoff | no | `archive_only` | **yes** |
| archived | pre_cutoff | yes | `RESIDUAL_COMPARISON_NOT_RECORDED` | no |
| archived | post_cutoff | no | `archive_post_cutoff_only` | no |
| archived | post_cutoff | yes | `RESIDUAL_ARCHIVE_POST_CUTOFF_WITH_CURRENT` | no |
| archived | mixed / unknown / absent / non-KNOWN | any | `RESIDUAL_ARCHIVE_DATE_UNKNOWN` | no |
| attempt_failed | — | any | `attempt_failed` | no |
| status=UNKNOWN_WITH_REASON | — | any | `RESIDUAL_ARCHIVE_POSTURE_UNKNOWN` | no |
| (else) | — | yes | `current_capture_only` | no |
| (else) status=NOT_ATTEMPTED | — | no | `not_attempted` | no |
| (else) | — | no | `RESIDUAL_NO_VISIBILITY_BASIS` | no |

**Dormant-by-design** (declared in the vocab, but the deriver must **never** emit them in v1):

- `archive_corroborated` / `archive_diverged` — need a recorded archive-vs-current
  comparison fact the producer does not store, so those cases route to
  `RESIDUAL_COMPARISON_NOT_RECORDED`.
- `not_applicable` **as a clear** — the immutable/official-source condition is "consumed,
  not designed" in the ratified contract, so v1 clears **only** on `archive_only`.
- `RESIDUAL_SLICE_DIVERGENT_VISIBILITY` — a per-slice no-hide rollup residual; this
  deriver is **per-packet flat** (one posture/packet), so it is not emitted. Flatness
  resolves the ratified field's `not_proven` vector-vs-flat refinement to *flat*,
  justified because producer packets are single-source and the packet-level
  `archive_history_posture` is already conservative.

## High-value checks (attack these)

- **(a) Table fidelity** — does `derive_source_visibility_postures` faithfully realize
  the table above? Scrutinize the D-branch disambiguation and the **`not_attempted`
  archive + current body → `current_capture_only`** call: is that right, or should a
  packet whose archive was never attempted but which has a current body grade
  differently?
- **(b) Dormant honesty** — are the three dormant paths genuinely unreachable in v1, or
  does any **silently drop a reachable case**? In particular: could a *real*
  `not_applicable` clear (an immutable/official source) be wrongly funneled to
  `RESIDUAL_NO_VISIBILITY_BASIS`? Could a real corroborated/diverged situation be
  mis-graded as `RESIDUAL_COMPARISON_NOT_RECORDED` in a way that loses signal a consumer
  needs?
- **(c) False-pass** — do the deriver tests pin concrete values tightly enough that a
  **wrong** table would fail them? Try to construct a table mutation that still passes
  `test_ecr_source_visibility_deriver.py`.
- **(d) Amendment binding** — is D consumed strictly as a class (the `KNOWN` value), with
  `mixed`/`unknown`/absent/non-KNOWN all collapsing to `RESIDUAL_ARCHIVE_DATE_UNKNOWN`,
  and **never** as a timestamp? Is the archive-body `slice_id` literal the *only*
  delta-sensitive coupling to the producer's naming, and is it isolated to one spot?
- **(e) Model integrity** — `EcrSourceVisibilityPosture`'s validator: XOR(`value`,
  `residual`); `clears_source_visibility` True **iff** value ∈ `{archive_only,
  not_applicable}`; `reason` required and non-blank when a residual is set. Can you
  construct an internally-inconsistent posture that still validates? Does any round-trip
  (`model_dump` → `model_validate`, including `mode="json"`) break under
  `extra="forbid"`?
- **(f) Purity** — any I/O, packet mutation, nondeterminism, or hidden
  EvidenceUnit/conductor/scoring coupling in the SP-6 path?

## Bundle manifest

**Under review (SP-6):**
- `orca-harness/ecr/models.py` — SP-6 = `SourceVisibilityValue`,
  `SOURCE_VISIBILITY_CLEARING_VALUES`, `SourceVisibilityResidual`,
  `EcrSourceVisibilityPosture` (rest of file = SP-1/2/3 context).
- `orca-harness/ecr/deriver.py` — SP-6 = the archive-slice helpers +
  `derive_source_visibility_postures` (rest = SP-1/2/3 context).
- `orca-harness/ecr/__init__.py` — exports + package contract docstring.
- `orca-harness/tests/unit/test_ecr_source_visibility_models.py` — model validation tests.
- `orca-harness/tests/unit/test_ecr_source_visibility_deriver.py` — the table tests.
- `orca-harness/tests/unit/test_ecr_source_side_composition.py` — mixed-grain integration
  (4 rows); SP-6 additions are the `_four_rows`/`archive_only_composes` tests.
- `orca-harness/tests/unit/_ecr_builders.py` — the test packet builder; the
  `archive_history` knob is the SP-6 addition.

**Context only — NOT under review** (the producer contract the deriver reads; use it to
verify the closed-vocab and grain claims above, but do not review it):
- `orca-harness/source_capture/models.py` — `VisibleFact` / `VisibleFactStatus`, the
  closed cutoff & archive-history vocabularies, `SourceCaptureSlice` /
  `SourceCapturePacket` grain and validators.

## Output (advisory; chat/transcript only — no repo writes, no file paths, no hashes)

- **Findings**, each with: severity, the file + symbol/section, the fidelity gap or
  false-pass, and a **concrete trigger** (an input packet that misgrades or an
  inconsistent model instance that validates).
- A **suggested minimal textual diff** per finding (you cannot apply it).
- A **verdict** on table-fidelity, dormant-honesty, model-integrity, and purity.
- A **residual-risk note**.
- If a finding is design-level (e.g., the flat shape is wrong, or a dormant deferral
  actually drops a reachable case), return **`NEEDS_ARCHITECTURE_PASS`**, stop, and
  describe the design problem instead of proposing a patch.

## Boundaries

Advisory only — you decide nothing that is auto-kept; the home author adjudicates each
finding against your citations. Review **only** the bundled source. This work is
**foundation**, not a readiness/validation/unfreeze claim for the frozen conductor —
which stays **frozen**. Make no scoring, readiness, or deployment claim.
