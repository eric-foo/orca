# Delegated Review-And-Patch Commission -- LinkedIn slice 3b-2 (FOLDED) -- v1

NO-REPO bundle. Reconstruct from /source, read /method, review against this
commission. Advisory cross-vendor discovery review.

## Lane Binding
- review_lane: code (workflow-code-review); mode: base-subagent
- actor_model_family_receipt:
  - author_home_model_family: anthropic (claude-opus)
  - controller_model_family: openai (gpt-5.5) -- YOU; different vendor (de-correlation satisfied)
  - current_receiving_actor_role: controller
  - dispatch_mode: external-controller-courier
  - de_correlation_status: satisfied
- Review with fresh priors.

## What changed since the v0 review (READ FIRST)
The v0 review (GPT-5.5) already reviewed `project_observation_to_candidate_row`'s
MINT-PATH + the observation/access-envelope BINDING and raised finding F1
(visible-influence free-text smuggle). F1 was accepted + patched. This v1 is the
FOLDED unit. The DELTA to focus on:
1. CONSOLIDATION: the F1 count/band guard was EXTRACTED from projection.py into the
   lane single-source module `capture_spine/linkedin_lane/shared_validation.py` as
   `validate_visible_influence_value` (`_VISIBLE_INFLUENCE_VALUE_RE` + 64-char cap).
   projection.py now IMPORTS + calls it (behavior-preserving refactor; codes
   unchanged: `oversized_visible_influence_number` / `invalid_visible_influence_number`).
2. OBSERVATION-GATE APPLICATION: `validate_live_observation`
   (`capture_spine/linkedin_live_adapter/validation.py`) now ALSO calls the guard for
   the two influence fields -- enforcing the minimization boundary at the OBSERVATION
   (the §6.2 seam), not only at the projection mint-path. Closes the residual that an
   observation record itself could hold an unminimized value.
3. +3 observation-level tests.
The MINT-PATH + BINDING logic is UNCHANGED from v0 (see
docs/review-outputs/adversarial-artifact-reviews/linkedin_live_projection_slice3b2_code_review_v0.md);
do not re-litigate it unless you spot a regression from the refactor.

## Review focus (the delta)
1. REFACTOR BEHAVIOR-PRESERVATION: does `shared_validation.validate_visible_influence_value`
   behave IDENTICALLY to the v0 projection-local helper (same accept/reject set; same
   codes)? Any change from moving `raise LinkedInLaneError(...)` to the shared `fail(...)`?
2. SHARED-HOME CORRECTNESS: is `shared_validation.py` the right home (lane SSOT; imports
   re + LinkedInLaneError; raises via fail)? Any import cycle / coupling issue?
3. OBSERVATION-GATE COMPLETENESS: does calling the guard in `validate_live_observation`
   fully close the boundary there? Is the placement (after the length-cap loop, before
   the person gate) correct? Any path where a smuggled influence value still validates?
4. FALSE-REJECT / MISSED-SMUGGLE (re-confirm): any legitimate minimized count/band value
   wrongly rejected, or any prose that passes the regex?
5. TESTS: do the 3 new observation tests + the 3 existing projection tests fully pin the
   two-gate behavior (distinct codes; non-hollow)?

## Controller output contract
- Run workflow-code-review (see /method).
- Findings + per-change citations (file + line), neutral, decision-sufficient.
- Bounded unified diff for accepted findings, touching ONLY shared_validation.py /
  projection.py / linkedin_live_adapter/validation.py / the test file.
- Verdict + residual-risk note. Escalation: NEEDS_ARCHITECTURE_PASS if the consolidation
  shape is wrong (findings only, no patch).

## Adjudication
Home model (anthropic/claude-opus) adjudicates as claims; final keep authority is the
home model's.

## Run the tests
Reconstruct /source (capture_spine/ + tests/ siblings), PYTHONPATH=root:
  python -m pytest tests/unit/test_linkedin_live_adapter.py -q
At author time: the bundled live-adapter test file runs 44; the full LinkedIn lane
(3 files, only this one shipped) is 109.

## Boundaries
Advisory cross-vendor discovery review. Not approval / validation / readiness /
live-runner / commercial authorization. Full content-level read-time minimization
remains slice 3c (runtime tape-test).
