# Bundle Manifest -- linkedin_live_projection_slice3b2_v1 (folded: projection + consolidated minimization guard)
# format: <git blob sha1>  <path under /source>

88f53b0113ee8ff306303cecf1fef39f9c9aa3b2  capture_spine/linkedin_lane/__init__.py
3ebb27aa55c53c886b3db6f8b4582dfbc39d7413  capture_spine/linkedin_lane/models.py
1ae4a5b3887a78a9169583e43a7b8bb8a0cc188d  capture_spine/linkedin_lane/validation.py
d87d2f94cc8c9916798714971de569ea09b4a7eb  capture_spine/linkedin_lane/shared_validation.py
e50f4d3eeb19f778bdd2bbd5177623bc5379b558  capture_spine/linkedin_live_adapter/__init__.py
dcded35d718394833c57d126a4e94ed2dcd6bd69  capture_spine/linkedin_live_adapter/models.py
00b4fa1aa90be1ce9eb75a9016865a6aa61f599c  capture_spine/linkedin_live_adapter/validation.py
79248009c395bc043e2cff4a675ea316d4df1fc1  capture_spine/linkedin_live_adapter/projection.py
bebc1f330dc1340b4f28d3cfe1070b4010fbafa6  tests/unit/test_linkedin_live_adapter.py
10b081cd89858275b83f81766e5a26dfe9b9a534  capture_spine/__init__.py
83e499aa75b61d42ba625a4f0c0e1bdbe071c974  tests/conftest.py
06ffc7232c6e4f0b852952bc03ca86b5065b5e53  pyproject.toml

method/adversarial_artifact_review_v0.md  5fc263a1d85e2b538389356cbe9ffb616d0c1913
method/review-lanes.md  43b1793d144687ae7c972f7f78deee41d5145b56
