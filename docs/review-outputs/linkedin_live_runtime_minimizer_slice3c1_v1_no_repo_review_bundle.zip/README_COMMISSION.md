# Delegated Review-And-Patch Commission -- LinkedIn slice 3c-1 (FOLD: observation-gate completion) -- v1

NO-REPO bundle. Reconstruct /source, read /method, review against this commission.
Advisory cross-vendor discovery review.

## Lane Binding
- review_lane: code (workflow-code-review); mode: base-subagent
- actor_model_family_receipt:
  - author_home_model_family: anthropic (claude-opus)
  - controller_model_family: openai (gpt-5.5) -- YOU; different vendor (de-correlation satisfied)
  - current_receiving_actor_role: controller
  - dispatch_mode: external-controller-courier
  - de_correlation_status: satisfied
- Review with fresh priors.

## What changed since the 3c-1 v0 review (READ FIRST)
Your v0 review found a CARRIED-BUT-UNCHECKED smuggle path: the minimizer
default-carries every LiveObservation field, and validate_live_observation only capped
5 free-text fields + 2 influence fields -- leaving minimization_rule,
observed_source_surface, person_data_minimized (non-person), the ids,
provenance_timestamp, and exclusions able to carry content. ACCEPTED.

The fix was FOLDED into the observation gate (the durable home), not band-aided into the
minimizer:
1. validate_live_observation now closed-value/shape-checks every carried field
   (capture_spine/linkedin_live_adapter/validation.py): observed_source_surface in
   SourceSurface; minimization_rule in MinimizationRule; person_data_minimized in
   PersonDataMinimized; observation_id/live_access_id/run_id are compact safe ids
   (<=128 chars, [A-Za-z0-9._:-]); provenance_timestamp is ISO-8601 UTC.
2. The minimizer now FORCES `exclusions` safe (never carries raw exclusion text),
   alongside schema_version + the 4 boundary flags
   (capture_spine/linkedin_live_runtime/minimizer.py).
This hardens BOTH the minimizer output AND the 3b-2 projection path (both run
validate_live_observation). 123 lane tests pass at author time.

## Target (the editable scope)
- capture_spine/linkedin_live_adapter/validation.py (validate_live_observation -- completed gate)
- capture_spine/linkedin_live_runtime/minimizer.py (exclusions forced-safe)
- tests: tests/unit/test_linkedin_live_adapter.py + tests/unit/test_linkedin_live_runtime.py

## Review focus (the fold)
1. COMPLETENESS: is EVERY carried LiveObservation field now closed-valued / capped /
   id-shaped / timestamp-shaped? Enumerate the dataclass fields and confirm none is
   still carried-but-unchecked. Buckets: forced-safe at the minimizer (schema_version,
   exclusions, 4 boundary flags); capped free-text (5); influence-guarded (2);
   closed-enum (entity_type, source_surface, minimization_rule, person_data_minimized);
   safe-id (3 ids); timestamp-shaped (provenance_timestamp). Anything missed?
2. FALSE-REJECT (likeliest defect): do the new checks reject a LEGIT value? The id
   charset [A-Za-z0-9._:-] and the Z-only UTC timestamp shape are the most plausible
   over-strictness -- would a real minimized id or a +00:00-offset timestamp be wrongly
   rejected? Flag any legit value the gate now blocks (fail-closed, but a usability
   defect worth knowing).
3. LAYER CORRECTNESS: is the observation gate the right home (vs the minimizer)? Confirm
   it also hardens the 3b-2 projection (which calls validate_live_observation).
4. EXCLUSIONS: is forcing exclusions safe in the minimizer right, or should the gate
   validate exclusions content instead (for any non-minimizer caller)?
5. FAKE-SUCCESS in tests: do the negatives assert the right distinct codes; any
   green-but-hollow assertion?

## Controller output contract
- Run workflow-code-review (see /method). Findings + per-change citations (file + line),
  neutral, decision-sufficient. Bounded unified diff for accepted findings, touching
  ONLY validation.py / minimizer.py / the two test files. Verdict + residual-risk note.
  Escalation: NEEDS_ARCHITECTURE_PASS if the gate-completion shape is wrong.

## Adjudication
Home model (anthropic/claude-opus) adjudicates as claims; final keep authority is the
home model's.

## Run the tests
Reconstruct /source (capture_spine/ + tests/ siblings), PYTHONPATH=root:
  python -m pytest tests/unit/test_linkedin_live_runtime.py tests/unit/test_linkedin_live_adapter.py -q
At author time the full LinkedIn lane (4 files) is 123; this bundle ships 2 of the 4
test files.

## Boundaries
Advisory cross-vendor discovery review. Not approval / validation / readiness /
live-runner / commercial authorization. 3c-1 is no-live (fixtures only); the real
fetcher (3c-2) stays behind the legal/ToS gate.
