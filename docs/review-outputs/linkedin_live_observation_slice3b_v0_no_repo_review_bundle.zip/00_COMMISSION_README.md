# Commission — Cross-Vendor Adversarial CODE Review (no-repo, advisory findings-only)

## What this is
You are commissioned as a **de-correlated, different-vendor adversarial CODE
reviewer** of **slice 3b** of the Orca LinkedIn live-adapter: the
**`LiveObservation` contract record + `validate_live_observation`** — the
no-runtime "observation" record that carries one minimized observed candidate
*before* projection into the core `CandidateRow`, and that is the seam where the
**§6.2 minimization boundary** must bite. You have **no repo access**; everything
is in this bundle. Output is **advisory findings only** (no diff). The home model
adjudicates.

## Who-constraint (de-correlation)
- **authored_by:** `claude-opus-4.x` (wrote it; will adjudicate).
- **reviewed_by:** YOU — a **different vendor/family** (GPT / Gemini / other non-Anthropic). State your model+vendor. If Anthropic-family, STOP.
- **de_correlation_bar:** `cross_vendor_discovery`.

## Scope (focus)
The NEW slice-3b additions in `review_target/`: `LiveObservation` (in `models.py`)
and `validate_live_observation` (in `validation.py`) + their exports + tests.
`LiveAccessEnvelope` (slice 3a, also in the same files) was reviewed already —
context, not the target.

## Design under review
- `LiveObservation` is **named-fields-only**: there is no field for a profile body / contact / follower list / content, so over-captured state cannot be carried structurally. The validator additionally requires the four `*_captured`/`*_retained` flags to be `False` (the belt-and-suspenders), and runs the imported forbidden-output-field walk.
- The record **links to a `LiveAccessEnvelope` via `live_access_id`**; it carries **no `non_claims`** of its own — the posture/non_claims lives on that run-level record (mirroring how core `CandidateRow` carries no non_claims; the observation is the pre-projection `CandidateRow`).
- Person observations (`observed_entity_type == individual_person`) are gated by the **shared** `validate_public_actor_basis` + a `person_data_minimized` ∈ {yes,no} check.
- No runtime, no projection into `CandidateRow` (that is a later slice).

## Method
Code review. Follow `02_PORTABLE_METHOD.md` as the procedure **plus** code-review judgment (correctness + the fake-success/hollow-test check).

## Authority (`authority/`)
- `AGENTS.md` — the kernel (Smallest Complete Intervention — conformance is part of the review).
- `live_layer_architecture_ADR_v0.md` — the accepted contract. **§6.2** (minimization boundary lives at the 3b seam, before lowering) and **§8 slice-3b** are the spec.
- `shared_validation.py` — the shared fail-closed primitives the observation validator reuses (verify the reuse is correct).
- `linkedin_lane__models.py` — `EntityType` / `PERSON_ENTITY_TYPES` (used in the entity-type + person gate) and `CandidateRow` (the projection target the observation mirrors).

## Attack hardest (decision-relevant)
1. **Does the minimization boundary actually hold?** Find ANY over-capture path: a field or nested shape that smuggles a profile body / contact / follower list / relationship graph / content past *named-fields-only + the flags + the forbidden-walk*. Is "named-fields-only" truly sufficient, or can the opaque-ish `*_or_none` string fields carry forbidden content the walk won't catch (it only scans for forbidden *keys* + secret *value patterns*)?
2. **Posture-by-reference soundness:** is "no `non_claims` on the observation; it lives on the `LiveAccessEnvelope` via `live_access_id`" actually safe, or should the observation carry its own disclaimer (defense-in-depth, like `FrontierNode` does)? The validator only requires `live_access_id` is present — it does not check the referenced envelope.
3. **Person-gate + reuse correctness:** is the shared `validate_public_actor_basis` applied correctly? Any person observation that should be rejected but passes (or vice-versa)?
4. **Hollow tests:** does each negative prove `validate_live_observation` RAISES on its targeted case (not constructor failure, not an earlier unrelated gate)?
5. **Faithfulness to ADR §6.2/§8-3b** + Smallest Complete (any scope inflation, or under-fix that leaves the seam open); any overclaim beyond "module + tests pass."

## Boundary
Findings are decision input only — not approval/validation/readiness/mandatory remediation. The home model adjudicates each as a claim; a bounded same-vendor recheck confirms closure before keep. `critical`/`major`/`minor` are priority labels only.

## Bundle map
```
00_COMMISSION_README.md   <- this file
02_PORTABLE_METHOD.md     <- general adversarial procedure
review_target/            <- the adapter (LiveObservation additions are the target) + tests
authority/                <- kernel + ADR + shared helpers + core models
```
