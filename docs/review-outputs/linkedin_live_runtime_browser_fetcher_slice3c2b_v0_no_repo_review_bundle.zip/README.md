# Adversarial Code Review (cross-vendor, NO-REPO) — LinkedIn lane slice 3c-2b: live BrowserFetcher

YOU ARE an independent reviewer from a different vendor than the author (anthropic/claude-opus). This is an **advisory cross-vendor discovery** review: your findings are decision input, not a verdict — the home model adjudicates every finding, citation, and proposed hunk as a *claim*, not a premise. You have **NO repository access**: reason ONLY from the artifacts and the SHA256 manifest in this bundle. Before reviewing, confirm each artifact's content matches its listed SHA256 (`MANIFEST.md`); if any file mismatches its hash, flag it and stop.

## What slice 3c-2b is
The real attended **BrowserFetcher** of a LinkedIn discovery lane: it turns a logged-in LinkedIn **company page** into a minimized candidate row. Posture (owner-set): owner-present attended automation, owner-accepted **POC-risk, ToS-gray, explicitly NOT "legally defensible."** Hard rules the code must honor:
- **Minimization** — business signal only: NO person / connection / follower-LIST / commenter / profile-body / contact data retained. (Visible follower *count/band* is allowed; a follower *list* is not.)
- **Fail-closed** — an unrecognized page captures nothing (extractor → `None`; fetcher → raise).
- **Clean CDP attach** — no stored credentials, no `storage_state`, no proxy, no synthetic stealth, no entitlement-gate bypass.

## Architecture (data flow)
`CdpAttachBrowserDriver` (the only live part; owner-validated, not unit-tested) → `extract_company_signal` (DOM → `CompanySignal`, offline) → `BrowserFetcher.fetch` (assembles a clean raw bag) → `run_live_capture` → minimizer (default-deny) → `validate_live_observation` (the observation gate) → projection (mints the candidate row). The extractor + BrowserFetcher composition is offline-tested; the live connect/navigate path is owner-validated.

## Review focus (highest value — prior slices' reviews found real issues here)
1. **Minimization-boundary completeness.** Trace EVERY path by which person / connection / social-proof / follower-LIST / profile-body content could reach the bag or the minted row — via the extractor's blocked-region depth tracking (does it actually suppress capture inside `org-top-card-secondary-content` / `social-proof`, including under malformed / missing-close-tag / nested DOM?), the follower normalization, or `BrowserFetcher` bag assembly. The minimizer is default-deny downstream, but is the extractor's OWN output strictly minimal?
2. **Fail-closed correctness.** Can an unrecognized, partial, truncated, or malformed page ever yield a guessed or partial result instead of `None` (extractor) / raise (`unrecognized_capture_page`, fetcher)? Consider: a page with the title class but no info-list; a second `org-top-card-summary__title`; a title inside the blocked region.
3. **Follower count/band regex (`_FOLLOWER_VALUE_RE`).** Does it admit free text, or admit a value the DOWNSTREAM observation gate (`_VISIBLE_INFLUENCE_VALUE_RE` in `shared_validation.py`, included as gate-context) would REJECT — causing a hard validation failure that loses the whole capture? Is it genuinely a subset of the downstream regex?
4. **CDP-attach posture.** Any path to stored credentials / `storage_state` / proxy / stealth / entitlement-gate bypass? Does `browser.close()` on a `connect_over_cdp` browser risk closing the OWNER's real browser or tabs? Is target validation (http(s)-only, no embedded creds) performed BEFORE the Playwright import so the offline guards are deterministic?
5. **Claim-boundary honesty.** Is "live connect/navigate path owner-validated, not unit-tested" correctly and honestly scoped, or does the code/test imply a stronger claim than the tests prove?

Also flag: any real (non-synthetic) data in the test fixture; any forbidden-field key that could survive into the bag; `observation_id` / `provenance_timestamp` format risks against the safe-id / UTC validators.

## Artifacts in this bundle (review these only)
`artifacts/orca-harness/capture_spine/linkedin_live_runtime/{extractor,browser_driver,fetcher,__init__}.py`, `artifacts/orca-harness/tests/unit/test_linkedin_live_runtime_browser_fetcher.py`. Read-only gate-context (do NOT review, use only for focus item 3): `artifacts/orca-harness/capture_spine/linkedin_lane/shared_validation.py`. `method_pins/` carries the review-standard docs (`adversarial_artifact_review_v0.md@5fc263a1`, `review-lanes.md@43b1793d`).

## Output (return in chat)
- **Findings** — each: severity (`blocker` / `major` / `minor` / `nit`), file + symbol/approx line, the finding, why it matters, and a per-finding **citation** to the specific code in the bundle (neutral in tone, decision-sufficient in substance).
- A **proposed unified diff** for accepted findings (the home model adjudicates and applies — you have no repo).
- **Verdict** + **residual-risk** note.
- If a design-level problem can't be fixed by a bounded patch, return **`NEEDS_ARCHITECTURE_PASS`** with findings only.

## Claim boundary
Advisory cross-vendor discovery only — NOT validation, readiness, live-runner, or commercial authorization. Claim under review = "module + its tests pass" (152 LinkedIn lane tests) ONLY. The live capture is owner-accepted POC-risk, ToS-gray, not legally-defensible.
