# No-Repo Review Bundle — LinkedIn lane slice 3c-2b (live BrowserFetcher)

Portable bundle for a cross-vendor adversarial CODE review with **no repository
access**. The reviewer reasons ONLY from the files in `artifacts/` — verify each
against its SHA256 below before reviewing. Start at `README.md` (the review prompt).

## De-correlation receipt
- author / home model family: **anthropic / claude-opus**
- controller (reviewer) family: **openai / gpt-5.5**  (different vendor → de-correlated)
- dispatch: external-controller-courier (no repo access)
- review lane: code (`workflow-code-review`), advisory cross-vendor **discovery**
- claim boundary: "module + its tests pass" (152 LinkedIn lane tests) ONLY — NOT
  validation / readiness / live-runner / commercial authorization. Live capture is
  owner-accepted **POC-risk, ToS-gray, NOT legally-defensible**.

## Review-target artifacts (SHA256)
```
9F812959A554714D823CFF6315329E5BEF85ACA4794B03B664E5226A76555E56  artifacts/orca-harness/capture_spine/linkedin_live_runtime/extractor.py        (NEW)
4A633A6210EF2A327FBDE34122BE0EED791435B4B0EE513D92052314433D758B  artifacts/orca-harness/capture_spine/linkedin_live_runtime/browser_driver.py   (NEW)
DE270AB73CC8075D0E9F5F7BE43002E69850F35171F5F4A731778B72CC121D9C  artifacts/orca-harness/capture_spine/linkedin_live_runtime/fetcher.py          (MODIFIED: + BrowserFetcher)
356AA50723A6A608E1B002E85EFD04321511C3F67A93E454BA80AA405CA379BA  artifacts/orca-harness/capture_spine/linkedin_live_runtime/__init__.py         (MODIFIED: exports)
1441385C17DC9F3FA9EAEF8FB9E3BD33A1DB3D1A741745816852FC02260BB36D  artifacts/orca-harness/tests/unit/test_linkedin_live_runtime_browser_fetcher.py (NEW, 15 tests)
```

## Gate-context (read-only reference; NOT under review)
```
AF970B7CB07CF7BBA03C099FE0EF9A4865F750F75DF509F05B915D385D33FBDC  artifacts/orca-harness/capture_spine/linkedin_lane/shared_validation.py
```
Provided so the reviewer can check **focus item (3)**: is `extractor._FOLLOWER_VALUE_RE`
genuinely a SUBSET of `shared_validation._VISIBLE_INFLUENCE_VALUE_RE` (so a normalized
follower value can never pass the extractor but be rejected by the downstream gate)?

## Method pins (git blob hashes, freshness-gated CURRENT at bundle time)
- `method_pins/adversarial_artifact_review_v0.md` @ `5fc263a1`
- `method_pins/review-lanes.md` @ `43b1793d`

## Verify before reviewing
Recompute the SHA256 of each `artifacts/` file and confirm it matches the list above.
If any file mismatches its listed hash, flag it and stop — the bundle is not trustworthy.
