# Review Brief — SCR v0 Deriver Build (no-repo adversarial code review)

You are an independent adversarial **code** reviewer from a **different model vendor/family than the author** (the author is an Anthropic model; you must not be one — this is a who-constraint for de-correlation, not a quality judgment). You have **no repository access** — review only the files in this bundle. Treat every claim as a claim to test, not a premise to accept. Try to break the build, then propose bounded code patches.

Stack: Python 3.12, pydantic v2, `StrictModel` = `extra="forbid"`.

## What you're reviewing (the build under review)

- `orca-harness/signal_content/deriver.py` — **the new deriver** (primary artifact). `derive_signal_content(packet, *, preserved_bodies, ecr_posture_refs=(), authored_interpretation=None) -> list[SignalContentRecord]`. Pure **carry-or-residualize**: one record per source slice that has a supplied body; the interpretive core (`signal_family`, `subject_entity`, `event_or_claim`, `signal_event_time`) is residualized because no authored-classification input exists in source.
- `orca-harness/signal_content/models.py` — includes the **D2=(b1) amendment** to `SignalEventTimeReference`: a `VisibleFact`-style `{status, packet_timing_field | None, reason}` + XOR validator (`status` defaults `KNOWN`).
- `orca-harness/signal_content/__init__.py` — the deriver export.
- `orca-harness/tests/unit/test_signal_content_deriver.py` — **the new test suite** (14 tests).

## Context (cited sources — verify the build's claims against these)

- `orca-harness/source_capture/models.py` — the **producer** model: `SourceCapturePacket`, `SourceCaptureSlice` (`preserved_file_ids`), `PacketTiming`, `PreservedFile` (path + sha256, **no body text**), and `VisibleFact` + its validator (the pattern D2 mirrors). Load-bearing for purity, the emit gate, and the D2 validator.
- `orca-harness/tests/unit/test_signal_content_models.py` — the **17 prior model tests**. The author claims D2 is additive/non-breaking — **verify these still hold under the amended model**.
- `orca-harness/tests/unit/_ecr_builders.py` — the `build_packet` fixture the tests use.
- `orca-harness/ecr/deriver.py` — the **sibling precedent** (pure M1/M2/M3 deriver) the SCR deriver mirrors.
- `docs/product/signal_content_record_deriver_architecture_plan_v0.md` — the **ratified spec (v0.1)** the build implements (the carry-supplied-or-residualize invariant, per-slice grain, residual-defaults, the build-time micro-decisions).
- `docs/product/core_spine_v0_signal_content_record_architecture_v0.md` — the owner direction brief.

## Current state (settled — pressure-test, don't relitigate)

- **Validation:** the author ran the full `orca-harness` suite — **538 passed, 1 skipped, 0 failed** (the 14 new deriver tests + the 17 prior model tests under the D2 amendment). Verify the suite actually covers what it claims; find what it misses.
- **Flagged build-time default (multi-body slice):** a slice with multiple supplied bodies → `raw_observation` = the bodies concatenated in `preserved_file_ids` order joined by a labeled boundary (`deriver.py:_BODY_BOUNDARY`). This is an agent-owned v0 default — judge whether it's honest/right or whether the owner should pick differently.
- **D2 anchor:** the deriver **never** selects publication-vs-edit; it emits the residual carrier. Confirm no code path mechanically picks an anchor.

## Attack the build — go hard on

- **Purity:** any hidden I/O, packet mutation, nondeterminism, or `EvidenceUnit` binding? Is re-derive determinism real (twice over the same frozen inputs → equal)?
- **Never-invent / honesty-under-absence:** can any interpretive field leak a value inferred from packet prose (`raw_observation`, `locator`, `requested_decision_context`)? Is `signal_family` ever populated without an authored input?
- **The emit gate:** is "no supplied body → no record" exhaustive (no-files slice / referenced-but-unsupplied / empty-or-whitespace body)? Any path that emits an empty or invented `raw_observation`?
- **D2 validator:** is the KNOWN-vs-residual XOR airtight (KNOWN ⇒ field set + no reason; non-KNOWN ⇒ no field + reason)? Does the additive change genuinely keep the 17 prior model tests valid?
- **`content_id`:** deterministic over `(packet_id, slice_id)` only, never body-dependent?
- **`ecr_posture_refs` + the dormant seam:** correct dedupe; does a non-None `authored_interpretation` fail loudly (it must)?
- **Test gaps:** what real case does the suite NOT cover that could hide a bug?

## Return format

Per finding: **severity** (blocker / major / minor) · **file + location** · **why** it's wrong or risky · a **proposed patch** (replacement code) · a **one-line citation** to a bundled file. End with an **overall verdict** (accept / accept-with-friction / needs-rework) and a **residual-risk note**.

Your findings, citations, and patches are **decision input only** — the author (home model) adjudicates each against the cited sources and decides what is kept.
