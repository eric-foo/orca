# No-Repo Delegated Review Commission — LinkedIn Graph Frontier Register, Slice 2 (v0)

You are a **DE-CORRELATED reviewer** with **NO repository access**. Everything you need is in this bundle. Review only from these files.

## De-correlation receipt (state this first, before any finding)
- Author / home model — `authored_by`: **Anthropic / Claude, Opus-class** (`claude-opus-4.8`).
- This is a **discovery** review (a full adversarial pass on new code). The discovery bar is **CROSS-VENDOR**: you must be a **different vendor / model lineage** from the author (vendor = upstream developer/provider — e.g. OpenAI/GPT, Google/Gemini — **not** a host, reseller, or wrapper).
- **State your model vendor + version** (`reviewed_by`, e.g. `gpt-5.5`). If you are an Anthropic/Claude model, **STOP** — you are same-vendor and cannot serve the cross-vendor discovery bar.
- `de_correlation_bar`: **cross_vendor_discovery**.

## Your method
- Use `context/portable_adversarial_review_method.md` — follow **only the delimited `PORTABLE METHOD` block** (stance, reasoning-before-findings, severity meaning, review-use boundary). No-repo, **advisory-only**: your result is advisory critique, not a formal verdict.
- **Override** (this is a code review-and-patch commission): return findings in **code-review schema** + *advisory* proposed edits the author applies/adjudicates. You do not touch a working tree.

## Target (review THIS; bounded scope)
- `target/capture_spine/linkedin_graph_frontier/models.py` — frozen dataclasses + StrEnums: `FrontierNode`, `FrontierEdge`, `FrontierDecision`, `NextRunEnvelope`; `FrontierNodeType` (8 source-shaped), `FrontierEdgeType` (11), `ProjectionDecision`; reuses `LinkedInLaneError`; schema-version constants; `DEFAULT_LINKEDIN_GRAPH_FRONTIER_NON_CLAIMS`; `to_dict`/`_enum_values`.
- `target/capture_spine/linkedin_graph_frontier/validation.py` — `validate_graph_frontier_register` + `validate_next_run_envelope`; node/edge-type allowlists; person-node privacy gate; `public_role_context` theme-linkage rule; `execution_authorized is False` guard; non_claims token check; **imports** the slice-1 forbidden-output-field walk.
- `target/capture_spine/linkedin_graph_frontier/__init__.py` — exports.
- `target/tests/test_linkedin_graph_frontier.py` — **19 tests pass** in the repo.
- **Attachment integrity:** `TARGET_SHA256.txt` lists each target's SHA256; recompute and confirm (if you can't, proceed advisory-only and say so).

## What this is — scope frame (do NOT flag deferred scope as a gap)
- **Slice 2 = the frontier DATA MODELS + their VALIDATORS + tests ONLY.** The register **builder** (assembling a register from candidate-intake output, like `reddit_graph_frontier/register.py`) and the **`PromotionReceipt`** are **deferred to slice 3 by design.** Do **not** flag their absence. **Do** flag if slice 2 overreaches into them.
- **Claim boundary:** the author claims ONLY "this module + its own tests pass." NOT lane validation/readiness, NOT a live runner, NOT promotion/capture, NOT a commit.

## Contract to check it against (authority — the target must conform)
- `context/data_capture_spine_linkedin_discovery_planning_lane_architecture_v0.md` — the frontier vocab source. Check the target against **"Graph Frontier Register Additions"** (allowed node types, edge types, forbidden graphs, the `public_role_context` "not general person tracking" rule), **"Semantic Projection"** (`promote`/`hold`/`quarantine`/`dead_end`), **"Hard Stops"**, **"Bounded Watch"**, **"Promotion Gate"**. *(This doc carries some uncommitted edits in unrelated sections — a person-basis corroboration sentence and an attended-automation variant — orthogonal to the frontier; check against the frontier sections.)*
- `context/linkedin_lane_operator_pilot_plan_v0.md` — the frontier **stage 3** ("a frontier hop needs a **new run** — no same-run traversal") + the acceptance gate.
- `context/AGENTS_kernel.md` — Agent Behavior Kernel + **Smallest Complete Intervention** (scope discipline). *(Overlay files it references are out of scope here.)*

## Referenced pattern it MIRRORS + REUSES (read-only — flag, don't patch)
- `context/reddit_graph_frontier_{models,validation,register}.py` — the capture_spine sibling this lane mirrors. `register.py` is the **builder** (slice 2 defers it) — verify the deferral is clean, not a gap. Verify the mirror is faithful **and** that slice 2 hardened appropriately beyond it (Reddit's frontier validator does NOT allowlist node/edge types on the raw mapping; this lane does).
- `context/linkedin_lane_{models,validation}.py` — slice 1. The target **imports** `LinkedInLaneError` + `assert_no_forbidden_output_fields` from here (same-family reuse, mirroring how `reddit_graph_frontier` reuses `reddit_candidate_intake`). Verify the reuse is correct **and** that the slice-1 `FORBIDDEN_OUTPUT_FIELDS` set actually covers the frontier's forbidden graphs.

## Adversarially check (be maximally adversarial within the bounded target)
**(a) Faithful to the frontier vocab.** Do the node types (8 source-shaped) + edge types (11) match the architecture exactly, and do the allowlists enforce them? Note: `frontier_decision`/`stop_event` are deliberately **not** node types — modeled as a separate `frontier_decisions[]` + a stop field/event (mirrors Reddit + the owner-locked "separate structures, not nodes" decision). Is that faithful to the architecture's node vocabulary without losing anything, or does excluding them break something?

**(b) Validators REAL — fake-success guard (load-bearing).** Does every negative actually **raise `LinkedInLaneError`**? Cover: forbidden field (top-level **and** nested); out-of-vocab node/edge type; edge to a missing node; person-node missing basis / wrong privacy / missing minimization / not-minimized; `public_role_context` missing theme linkage; invalid projection decision; decision to a missing node; duplicate node_id; hollow non_claims; `execution_authorized=True`; missing caps. **IMPORTANT:** a None-truthiness bug was already caught and fixed in build (`str(None).strip()` is the truthy string `"None"`, so a "required" check silently passed) — **scan for any remaining check that does `str(x.get(field, "")).strip()` on a field that can be `None` and would slip past.** Any bad input that should raise but slips through?

**(c) Person-privacy fidelity.** Do person-candidate nodes (`public_professional_actor` / `senior_decision_maker` / `creator_or_influencer`) carry the slice-1 person gate (a concrete org-chart-independent public-actor basis + `privacy_sensitivity` in the person set + a `minimization_rule` + `person_data_minimized` yes/no)? Does the `public_role_context` edge require a theme linkage? Faithful to the architecture's person rules?

**(d) Forbidden-graph coverage.** Do the imported slice-1 walk + the edge-type allowlist together block every forbidden graph (follower / connection / commenter / employment / org-chart / contact graph + lead list)? Any bypass — a banned graph reachable as an edge-type *value* (caught by the allowlist?), a nested *key* (caught by the walk?), or a key the slice-1 set misses? Is importing (not duplicating) the walk correct — does the slice-1 set fully cover the frontier's forbidden set?

**(e) Each-hop-new-run guard.** `NextRunEnvelope.execution_authorized` must be `False` (the validator rejects `True`). Does this + the separate-envelope structure actually prevent same-run traversal / auto-execution? Is there a path to a same-run hop the validator misses?

**(f) Scope discipline (AGENTS kernel).** Is slice 2 the smallest **complete** intervention — data models + validators (durable, not symptom-only) without the register builder or `PromotionReceipt` (correctly deferred)? Flag both overreach (into slice-3 promotion/builder) and underfix.

**(g) Evolution-safety.** Additive enum growth; the allowlists derived from the enums (auto-tracking); the imported walk tracking the slice-1 set as it grows.

## Return (NO repo access — you CANNOT edit the working tree)
- Lead with the portable method's `review_summary` block, then findings in **code-review schema**, ordered `critical` → `major` → `minor`: `severity` (priority label only), `location` (file + symbol/line), `issue`, `evidence` (cite the target section **and** the conflicting authority excerpt by name/section), `impact`, `minimum_closure_condition`, `next_authorized_action`.
- For accepted findings, **advisory** proposed edits (unified diff / exact replacement blocks) against `target/` **only** — claims the author applies + adjudicates.
- Design-level problem (architecture/pilot wrong, or the dataclass pattern unfit) → **`NEEDS_ARCHITECTURE_PASS`** (findings only).
- **State your model vendor + version** (`reviewed_by`) for the provenance record. The author records `authored_by: claude-opus-4.8` and `de_correlation_bar: cross_vendor_discovery` on ingest.

## Boundary
Portable (no-repo) delegated **advisory** review under a **provisional** Orca convention. Your findings are **decision input only** — not approval, validation, readiness, product proof, mandatory remediation, or executor-ready instructions. The author (CA) adjudicates what is kept; a **required bounded same-vendor post-patch re-review** runs before anything is kept. Nothing here is committed; nothing downstream is bound unless a separate authorized decision accepts it.
