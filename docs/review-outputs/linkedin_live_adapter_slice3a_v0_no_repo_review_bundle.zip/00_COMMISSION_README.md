# Commission — Cross-Vendor Adversarial CODE Review (no-repo, advisory findings-only)

## What this is
You are commissioned as a **de-correlated, different-vendor adversarial CODE
reviewer** of one harness slice: **slice 3a of the LinkedIn live-adapter** — a
no-runtime `LiveAccessEnvelope` contract record + its fail-closed validator +
tests. You have **no repo access**; everything you need is in this bundle. Your
output is **advisory findings only** — you do NOT propose or apply a diff (no
repo). The commissioning home model adjudicates what is kept.

## Who-constraint (de-correlation)
- **authored_by:** `claude-opus-4.x` (wrote the code; will adjudicate your findings).
- **reviewed_by:** YOU — must be a **different vendor/family** (GPT / Gemini / other non-Anthropic). State your model+vendor. If you are Anthropic-family, STOP — de-correlation unsatisfied.
- **de_correlation_bar:** `cross_vendor_discovery`.

## Method
This is a **code review**. Follow `02_PORTABLE_METHOD.md` as the general
adversarial procedure (reasoning-before-findings; severity = priority labels
only; advisory-only), AND apply code-review judgment beyond it — the portable
method is artifact-oriented, so add **correctness** and the **fake-success /
hollow-test** check below. Confirm each `review_target/` file against the SHA256s
the commissioner gives you out-of-band; if you cannot, proceed advisory-only and say so.

## The target (in `review_target/`)
- `models.py` — `LiveAccessEnvelope` frozen dataclass + `LiveAccessMode` + `to_dict`.
- `validation.py` — `validate_live_access_envelope` (the fail-closed gate).
- `__init__.py` — package exports.
- `test_linkedin_live_adapter.py` — the tests (13).

## Authority / grounding (in `authority/`)
- `AGENTS.md` — the Orca kernel. **Conformance to Smallest Complete Intervention is part of the review** (flag scope inflation AND underfix).
- `live_layer_architecture_ADR_v0.md` — the accepted contract this code implements. §8 slice-3a is the spec: presence-attested + no-bypass + execution-not-authorized + attended-mode as **enforced predicates**, in the **adapter** (not the core), **no runtime**.
- `linkedin_lane_models.py` + `linkedin_lane_validation.py` — slice 1, which this code IMPORTS (`LinkedInLaneError`, `assert_no_forbidden_output_fields`) and mirrors. You need these to judge whether the import + reuse is correct.
- `linkedin_graph_frontier_validation.py` — slice 2, whose negated-non_claims (`_is_negated`) pattern this code mirrors.

## Attack hardest (code-specific, decision-relevant)
1. **Hollow tests:** does any negative test pass for the WRONG reason — e.g. raising at dataclass construction rather than in `validate_*`, or the "bad" input not actually exercising the targeted predicate? Does each negative genuinely prove the validator RAISES on its targeted bad case?
2. **Does the gate actually enforce what it claims?** Find ANY bad input that SLIPS through: a forbidden field / aliased key, a bad enum value, an unknown key, `entitlement_gate_bypass=True`, `owner_presence_attested` falsey-but-not-False, `execution_authorized=True`, the POC-risk mode without its flag, or a positive `non_claims` that satisfies a category.
3. **Truthiness traps:** the predicates use `is not True` / `is not False`. Probe whether a truthy/falsy non-bool (1, 0, "true", None) can defeat or wrongly trip a check.
4. **Isolation invariant:** does the adapter import the core **one-way only** (adapter → core)? Any core mutation, or any core→adapter import, would break it. Could deleting this package leave slices 1+2 intact?
5. **Correctness vs the ADR contract:** does the code implement §8 slice-3a faithfully, and does it stay **no-runtime** (no browser/session/fetch/IO)?
6. **`_is_negated` robustness:** can a cleverly-worded claim satisfy a hard-stop category while not actually disclaiming it (or vice-versa)?
7. **Overclaim / scope:** any readiness/validation/safety claim beyond "module + its tests pass"; any scope inflation vs Smallest Complete.

## Boundary
Findings are **decision input only** — not approval, validation, readiness, or mandatory remediation. The home model adjudicates each as a claim (accept/modify/reject); a bounded same-vendor recheck confirms closure before anything is kept. `critical`/`major`/`minor` are priority labels only.

## Bundle map
```
00_COMMISSION_README.md   <- this file
02_PORTABLE_METHOD.md     <- general adversarial procedure (combine with code judgment)
review_target/            <- the slice-3a code under review (4 files)
authority/                <- kernel + ADR contract + imported/mirrored slice-1/2 code
```
