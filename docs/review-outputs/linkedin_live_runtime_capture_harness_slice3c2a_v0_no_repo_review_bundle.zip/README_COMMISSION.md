# Delegated Review-And-Patch Commission -- LinkedIn slice 3c-2a (attended capture harness) -- v0

NO-REPO bundle. Reconstruct from /source, read /method, review against this commission.
Advisory cross-vendor discovery review.

## Lane Binding
- review_lane: code (workflow-code-review); mode: base-subagent
- actor_model_family_receipt:
  - author_home_model_family: anthropic (claude-opus)
  - controller_model_family: openai (gpt-5.5) -- YOU; different vendor (de-correlation satisfied)
  - current_receiving_actor_role: controller
  - dispatch_mode: external-controller-courier
  - de_correlation_status: satisfied
- Review with fresh priors.

## What this is
slice 3c-2a is the NO-LIVE half of the live runtime: the attended-capture HARNESS. It is
the runner skeleton + the legal-gate-as-code, with the live fetch behind an injectable
seam. The real attended BrowserFetcher (3c-2b) -- the ONLY part that touches LinkedIn --
is NOT in this bundle; it is owner-validated on an attended run, behind the legal/ToS
gate. The owner has authorized the live path as POC-risk (eyes-open, ToS-gray, not
"legally defensible"); this harness is the no-live scaffold for it.

Files:
- capture_spine/linkedin_live_runtime/fetcher.py -- the Fetcher Protocol + StubFetcher (offline).
- capture_spine/linkedin_live_runtime/runtime.py -- run_live_capture: the gate + caps + the
  fetch->minimize(3c-1)->validate->project(3b-2) wiring; CaptureTarget (per-target operator judgment).
- the rest of /source is read-only context (minimizer, adapter gate, projection, lane core).

## Authorization model (review this)
The LiveAccessEnvelope stays a POSTURE record with execution_authorized=False (the 3a
contract; the 3b-2 projection binds to it unchanged). The live-run authorization is a
SEPARATE explicit owner arg to run_live_capture (live_run_authorized) + owner_present_confirmed.
This avoids the conflict where a True envelope would fail the projection's binding.

## Review focus (attack these)
1. GATE BYPASS: can run_live_capture do ANY fetch/mint without live_run_authorized=True AND
   owner_present_confirmed=True? Is the gate strictly before any fetcher.fetch call? Are the
   `is not True` checks right (reject None/truthy-non-True)?
2. AUTHORIZATION MODEL: is the separate-arg model sound? Does validate_live_access_envelope
   (still requiring execution_authorized=False) correctly validate the posture here, and does
   the projection binding still hold? Any way the posture/run envelopes go unvalidated?
3. CAP ENFORCEMENT: _resolve_cap (1 <= max_captures <= sum(envelope.caps.values())) + the loop
   break at len(rows) >= cap -- off-by-one? Can the run exceed the declared posture caps?
4. WIRING / NO UNVALIDATED ESCAPE: every returned row goes through minimize -> project (which
   ends in validate_candidate_row). Can an unvalidated or non-minimized row escape? Does a
   per-target failure leave a partial/garbage row in the result?
5. FETCHER SEAM: is the Protocol boundary clean (fetcher only fetches; minimize/validate/project
   are the runtime's)? StubFetcher fails closed on an unknown target -- good? The real
   BrowserFetcher is OUT OF SCOPE (gated) -- do not review code that is not here.
6. FAKE-SUCCESS in tests: do the gate negatives assert the right codes; is the wiring test a
   real proof (validate_candidate_row + planted-content-dropped); any green-but-hollow assertion?

## Controller output contract
- Run workflow-code-review (see /method). Findings + per-change citations (file + line), neutral,
  decision-sufficient. Bounded unified diff for accepted findings, touching ONLY runtime.py /
  fetcher.py / the harness test. Verdict + residual. Escalation: NEEDS_ARCHITECTURE_PASS if the
  harness/gate/authorization shape is wrong.

## Adjudication
Home model (anthropic/claude-opus) adjudicates as claims; final keep authority is the home model's.

## Run the tests
Reconstruct /source (capture_spine/ + tests/ siblings), PYTHONPATH=root:
  python -m pytest tests/unit/test_linkedin_live_runtime_capture.py tests/unit/test_linkedin_live_runtime.py -q
At author time the full LinkedIn lane (5 files) is 132; this bundle ships the 2 runtime test files.

## Boundaries
Advisory cross-vendor discovery review. Not approval / validation / readiness / live-runner /
commercial authorization. The harness is no-live (StubFetcher only); the real BrowserFetcher
(3c-2b) stays behind the legal/ToS gate and is owner-validated, not in scope here. The live
path is owner-accepted POC-risk -- ToS-gray, explicitly NOT "legally defensible".
