# Review Brief — SCR Deriver Architecture (no-repo adversarial artifact review)

You are an independent adversarial reviewer from a **different model vendor/family than the author** (the author is an Anthropic model; you must not be one). You have **no repository access** — review only the files in this bundle. Treat every claim as a claim to test, not a premise to accept. Try to break the architecture, then propose bounded text patches with citations.

## What you're reviewing

The **Signal Content Record (SCR) deriver architecture** — the plan for a pure deriver that reads a captured packet and produces a `SignalContentRecord`. It **carries** the mechanical fields (keys, verbatim `raw_observation`, an event-time reference, a neutral routing tag) and **residualizes** the interpretive core (`signal_family` + the event/claim) because no authored classifier exists yet. The deriver must **never author or guess** family or content.

Primary artifact under review:
- `docs/product/signal_content_record_deriver_architecture_plan_v0.md`

Cited sources (review the artifact's claims against these):
- `docs/product/core_spine_v0_signal_content_record_architecture_v0.md` — the owner-decided direction brief.
- `orca-harness/signal_content/models.py` + `__init__.py` — the v0 `SignalContentRecord` model the deriver fills.
- `orca-harness/source_capture/models.py` — the **producer** model (`SourceCapturePacket`, `SourceCaptureSlice`, `PacketTiming`, `PreservedFile`, `VisibleFact`) the deriver reads. **Load-bearing for the carry mappings and the open finding below.**
- `orca-harness/ecr/deriver.py` + `orca-harness/ecr/models.py` — the SP-6 deriver precedent (M1-carry / M2-derive / M3-residual) the SCR deriver mirrors.
- `docs/product/jsg01_sp6_source_visibility_derivation_architecture_plan_v0.md` — the SP-6 architecture precedent.
- `orca-harness/tests/unit/test_signal_content_models.py` — the model tests (the validation bar the build mirrors).

## Current state (settled — pressure-test, don't relitigate)

- **D2 (the `signal_event_time` honesty gap) is RESOLVED as path (b):** add an unresolved carrier to `SignalEventTimeReference`; recommended sub-shape = a `VisibleFact`-style `{status, packet_timing_field | None, reason}` (additive; `status` defaults to `known` so existing records/tests are unaffected). Pressure-test whether this is genuinely honest and minimal, or introduces a flaw.
- **Home-model OPEN FINDING — verify and extend, don't just rediscover:** `PreservedFile` (in `source_capture/models.py`) carries a file *path + sha256 + size*, **not inline body text** — so a pure no-I/O deriver `(packet) -> records` **cannot fill** the required `raw_observation` (a verbatim source-language anchor) from `packet` alone. Proposed fix: the deriver takes **caller-supplied preserved bodies** (the file-read stays in a thin caller; the deriver stays pure). **Confirm this against `source_capture/models.py`, judge the fix, and find anything analogous the author missed.**

## Attack surface — go hard on

- Does "residualize-default + dormant authored seam" truly preserve honesty, or does it hide an authoring act (the `decision_relevance` routing tag? selecting which `PacketTiming` field is the event-time anchor?)?
- Is the content↔integrity "linked-by-key, never-merged" boundary actually held by the per-field mapping, or is something embedded/merged?
- Are "never invent family/content" and "state-1 not-extracted vs state-2 extracted-but-empty" actually enforceable by the model/validators, or are there gaps?
- Does "re-derive from frozen raw" survive the open finding above?
- Any other place the architecture quietly assumes an input the source does not provide.

## Return format

For each finding: **severity** (blocker / major / minor) · the exact **claim or section** · **why** it's wrong or risky · a **proposed patch as replacement text** · a **one-line citation** to the bundled source that supports it. End with an **overall verdict** (accept / accept-with-friction / needs-architecture-pass) and a **residual-risk note**. If a problem is design-level rather than a text fix, return **NEEDS_ARCHITECTURE_PASS** and do not paper over it with a patch.

Your findings, citations, and patches are **decision input only** — the author (home model) adjudicates each against the cited sources and decides what is kept. Keep citations neutral in tone but decision-sufficient in substance.
