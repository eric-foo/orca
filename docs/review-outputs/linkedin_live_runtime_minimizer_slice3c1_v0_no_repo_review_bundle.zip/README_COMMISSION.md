# Delegated Review-And-Patch Commission -- LinkedIn slice 3c-1 (read-time minimizer + tape-test) -- v0

NO-REPO bundle. Reconstruct from /source, read /method, review against this
commission. Advisory cross-vendor discovery review.

## Lane Binding
- review_lane: code (workflow-code-review); mode: base-subagent
- actor_model_family_receipt:
  - author_home_model_family: anthropic (claude-opus)
  - controller_model_family: openai (gpt-5.5) -- YOU; different vendor (de-correlation satisfied)
  - current_receiving_actor_role: controller
  - dispatch_mode: external-controller-courier
  - de_correlation_status: satisfied
- Review with fresh priors.

## What this is
Slice 3c-1 is the NO-LIVE half of the live runtime: the READ-TIME MINIMIZER + its
proof. The real browser that visits LinkedIn is slice 3c-2 -- behind a legal/ToS gate,
NOT in this bundle. 3c-1 is a pure transform: given an over-captured raw field bag
(whatever a fetcher pulled off a page, possibly with forbidden over-capture), keep
ONLY the named minimized LiveObservation fields, drop everything else, validate. It is
the runtime half of the §6.2 minimization boundary -- the "tape-test" proof that what
we KEEP is a strict minimization of what was READ. No I/O; fixtures are offline dicts;
never connects to LinkedIn.

Design (locked): minimize-SILENTLY -- drop forbidden keys, force the boundary flags
safe via a read-set that excludes them. REJECTING a bag merely because it shows
over-capture is a deferred refinement, not in 3c-1 (challenge if you think that's wrong
-- focus area 5).

## Target (the editable scope)
- PRIMARY: capture_spine/linkedin_live_runtime/minimizer.py -- minimize_capture_to_observation
- tests: tests/unit/test_linkedin_live_runtime.py (the tape-test)
- supporting context (READ-ONLY; flag if implicated): the adapter (LiveObservation +
  validate_live_observation), shared_validation, the lane core.

## Why source-read-only review is insufficient
The minimization GUARANTEE (no forbidden over-capture survives into the output) is the
whole point. We want adversarial attempts to BREAK it -- find a bag that smuggles
forbidden content into the minimized observation -- plus a bounded patch for any hole.

## Review focus (attack these)
1. DEFAULT-DENY COMPLETENESS: the read-set is `LiveObservation fields minus the
   forced-safe set`, derived from the dataclass. Can ANY non-allowed key in the bag
   reach the output? Is the dataclass-derived read-set sound (any field that should
   NOT be carried but would be)?
2. FORCED-SAFE FLAGS: the four minimization-boundary flags + schema_version are forced
   to defaults (never read from the bag). Can a bag override them? Is the forced-safe
   set complete?
3. CONTENT SMUGGLE INTO AN ALLOWED FIELD: a bio in observed_display_name -> length cap;
   prose in a count field -> influence guard. Are there allowed fields with NO cap
   where content still smuggles (e.g. observed_source_locator, minimization_rule,
   observation_id)? Is validate-on-output sufficient, or does the minimizer need its
   own caps?
4. THE TAPE-TEST ITSELF: is it a REAL proof? It plants profile body / email / follower
   list / raw html / True flags and asserts absence from json.dumps(result). Is
   `not in json.dumps(result)` a sound absence check, or can content hide (nested,
   encoded, partial)? What forbidden case is NOT tested?
5. MINIMIZE-SILENTLY vs REJECT: is silently dropping over-capture right, or should
   evidence of over-capture (a forbidden key, a True retained-flag) be REJECTED and
   surfaced instead of absorbed? We deferred reject -- challenge if that is unsafe.
6. ERROR TYPES: missing-required + non-mapping raise LinkedInLaneError (not bare
   TypeError/KeyError)? Any unguarded path raising the wrong type?
7. FAKE-SUCCESS in tests: do negatives assert the right codes; any green-but-hollow
   assertion?

## Controller output contract
- Run workflow-code-review (see /method). Findings + per-change citations (file +
  line), neutral, decision-sufficient.
- Bounded unified diff for accepted findings, touching ONLY minimizer.py + the test
  file. Verdict + residual-risk note. Escalation: NEEDS_ARCHITECTURE_PASS if the
  minimize-only shape itself is wrong.

## Adjudication
Home model (anthropic/claude-opus) adjudicates as claims; final keep authority is the
home model's.

## Run the tests
Reconstruct /source (capture_spine/ + tests/ siblings), PYTHONPATH=root:
  python -m pytest tests/unit/test_linkedin_live_runtime.py -q
At author time: this file runs 7; the full LinkedIn lane (4 files, only this one
shipped) is 116.

## Boundaries
Advisory cross-vendor discovery review. Not approval / validation / readiness /
live-runner / commercial authorization. 3c-1 is no-live (fixtures only); the real
fetcher (3c-2) stays behind the legal/ToS gate. The tape-test proves representative
planted content is dropped + validator-pass -- a strong concrete check, not a universal
guarantee.
