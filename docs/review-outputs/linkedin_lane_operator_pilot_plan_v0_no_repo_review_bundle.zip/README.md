# Delegated Review-And-Patch Commission — LinkedIn Lane Operator Pilot Plan v0 (no_repo, advisory)

This is a **provisional, opt-in, no-repo** delegated review-and-patch commission
under `.agents/workflow-overlay/delegated-review-patch.md`. It is **advisory**
(not a bound/formal review lane, not validation, not readiness). The reviewer
has **no repo, skill, or overlay access** and follows the embedded portable
method.

## Lane Binding

```yaml
overlay_status: provisional_opt_in            # explicit CA commission; not a bound lane; not mandatory
operating_contract_pointer: .agents/workflow-overlay/delegated-review-patch.md
review_lane: artifact (adversarial-artifact-review)   # non-code artifact
access: no_repo                                # delegate is advisory-only; returns FINDINGS, NOT a diff; the CA applies the patch
mode: no_repo_advisory_base                    # single de-correlated advisory pass
freshness_gate: PASS                           # portable-method derived_from pins hash-match live sources (verified pre-bundle 2026-06-09):
                                               #   adversarial_artifact_review_v0.md  0cb80057...b60c3fc  (match)
                                               #   review-lanes.md                    b8569fb5...057f6884 (match)
```

## Actor / Model-Family Receipt (de-correlation — a WHO-constraint, not a model recommendation)

```yaml
author_home_model_family: Anthropic Claude (Opus-class)   # authored the pilot plan AND adjudicates (CA)
controller_delegate_model_family: <operator selects>      # MUST be a DIFFERENT family AND non-Opus (e.g. a GPT-family model)
current_receiving_actor_role: controller                  # you, the reviewer, are the de-correlated controller
dispatch_mode: external-controller-courier                # no_repo: operator couriers your findings back to the CA
de_correlation_status: satisfied_iff_delegate_is_non_opus_different_family
fallback: if no different-family non-Opus model is available, DO NOT claim this lane; fall back to source-read-only review + CA self-review and record the limitation.
```

This names model *families* only to express the difference constraint. It is
**not** a runtime-model recommendation, ranking, or routing.

## Target (the editable scope — but in no_repo YOU do not edit it)

- `target/linkedin_lane_operator_pilot_plan_v0.md`
- **SHA256 (confirm before reviewing):** `057ba0f32389ce6f80ac5ae518303c76779bc82943ccc7528ac81075cb850da0`
- It is shipped as a **verbatim file attachment** (not embedded in this README) so the hash is byte-confirmable. Confirm the hash; if it does not match, proceed advisory-only and say so.
- **Bounded patch scope:** the pilot-plan file only. Everything in `authority/` is reference the target must conform to — **flag, never propose editing it.**

## Why a de-correlated review (not author self-review)

The pilot plan is a **safety-sensitive operating procedure** authored by an
Opus-class model. Self-review is correlated with the author's blind spots. Be
**maximally adversarial** about whether an operator/agent **following the
procedure exactly as written** could still:

- leak person data, or qualify/keep a person row **without** a concrete,
  org-chart-independent public-actor basis;
- retain a forbidden field or build a forbidden graph (contact, follower,
  connection, commenter, employment-history, full org chart, lead list);
- capture a profile body or post content;
- reach **non-entitled** data, or let the supervised-browser-assist POC-risk
  variant's anti-blocking drift past **discoverable-or-entitled** surfaces (the
  `no-entitlement gate bypass` hard stop);
- auto-promote, or treat `caps_reached` as coverage;
- **loosen, contradict, or silently widen any rule in `authority/01`** (the
  accepted architecture) — the pilot plan must add **sequencing + a no-live
  default**, never new permission;
- over- or under-reach per the Smallest Complete Intervention rule in
  `authority/02` (does it do more, or less, than operationalizing the accepted
  lane requires?).

Also check the **acceptance gate is genuinely checkable** (each condition an
observable presence/absence), the no-live default truly defaults off, and the
POC-risk variant stays strictly opt-in with its hard stops intact.

## Method (you have no skills/overlay — follow the embedded method)

Follow `method/portable_adversarial_artifact_review_method.md` exactly. Return
its output contract: a compact `review_summary`, then findings ordered
`critical → major → minor`, each with `severity`, `location`, `issue`,
`evidence` (cite the **pilot-plan section AND the conflicting `authority/`
excerpt**), `impact`, `minimum_closure_condition`, `next_authorized_action`, and
an advisory remediation **direction**. **Return FINDINGS, not a diff, and no
executor-ready patch steps** (no_repo mode). If you find none, say so and list
residual risks / gaps.

Escalation: if the procedure cannot be made safe **without changing the
architecture** in `authority/01` (a design-level problem, not a wording fix),
say so explicitly as `NEEDS_ARCHITECTURE_PASS` — that routes back to the
architecture lane, not a patch.

## Bundle Manifest

```text
README.md                                              # this commission
target/linkedin_lane_operator_pilot_plan_v0.md         # the review target (hash above)
authority/01_accepted_linkedin_lane_architecture.md    # controlling source — the target must stay strictly inside it
authority/02_agents_kernel.md                          # AGENTS.md — behavior kernel + Smallest Complete Intervention (scope discipline)
method/portable_adversarial_artifact_review_method.md  # the portable review method (component c)
```

Not bundled (reference only; flag `unverifiable from provided sources` if you
need them): the source-access boundary decision and the Candidate URL Intake
parent contract — `authority/01` summarizes the relevant boundary and hard
stops.

## Adjudication Contract (home / CA model — applies AFTER your return)

Your findings are **decision input only**. The CA will: adjudicate each finding
as a claim (accept / modify / reject) against the cited authority and the
artifact's intent; apply accepted changes to the pilot-plan file within the
bounded scope; then commission a **REQUIRED de-correlated post-patch re-review**
(a second different-family advisory pass, bounded to closure-of-findings plus any
new blocker/major in the delta) before anything is kept. Nothing here is bound
until that adjudication and re-review resolve.

## Non-Claims

Provisional convention. Not validation, not readiness, not formal review
authority, not a bound/mandatory/machine-routable review lane, not runtime model
routing, not patch authorization beyond the CA's bounded application, not
live-LinkedIn / POC-risk-variant authorization. De-correlation is a
who-constraint recorded for the commission, not a model-quality claim.
