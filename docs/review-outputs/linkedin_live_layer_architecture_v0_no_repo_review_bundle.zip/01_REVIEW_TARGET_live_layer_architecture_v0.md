```yaml
retrieval_header_version: 1
artifact_role: Target architecture recommendation (planning-only; under adversarial review)
scope: >
  The target architecture for a NEW "live" layer of the Orca LinkedIn discovery
  lane. Today the lane is no-live / planning-only. The owner reanchored it to LIVE
  targeted discovery. This artifact recommends the live layer's target
  architecture for owner sign-off. It is planning-only: no code, no route, no
  readiness claim.
authority_boundary: retrieval_only
status: DRAFT — pre-sign-off; submitted for cross-vendor adversarial artifact review
authored_by: claude-opus-4.x (home model)
conforms_to:
  - authority/AGENTS.md  (kernel; Smallest Complete Intervention)
  - authority/linkedin_lane_architecture_v0.md  (committed lane architecture: Hard Stops, Non-Claims, person-basis, D5)
  - authority/linkedin_lane_index_v0.md  (entry map; hard rails)
```

# Live LinkedIn-Layer — Target Architecture Recommendation (v0, DRAFT)

## 1. The decision

Where does the ToS-risky live-access runtime sit relative to the proven no-live
core (slices 1+2 — `linkedin_lane`, `linkedin_graph_frontier`), and how is
"signal-agnostic extraction" represented at the seam between them?

## 2. Accepted direction + frozen envelope (not under review — context)

- **Live access, owner-present/attended only.** Two modes: (1) manual you-at-the-keyboard + tool-assist; (2) owner-present autonomous automation (bot runs ONLY with confirmed human presence; POC-risk explicitly accepted by owner).
- **No entitlement-gate bypass.** No circumventing login walls, rate/commercial-use caps, or paid tiers; no fake/multiple accounts. **No black-letter ToS violations.** Single real account, attended.
- **Signal-agnostic + fail-closed extraction.** Plumbing must be general (point at any signal; do not hardwire a fixed signal set — owner may pivot on what data matters), BUT the rails decide what is allowed OUT (default-deny; public-actor basis, minimization, no junior/ordinary dossiers, no contact/graph/content over-capture). General capability, NOT broad capture.
- **Targeted/frontier discovery, NOT bulk sweep.** Verified reachability: inside the no-bypass envelope, public-actor + public-edge signal suffices for targeted discovery; the ~300/mo commercial-use search cap bites bulk, not targeted.
- **Legal/ToS safety = DEFERRED HARD graduation-gate** (POC-bounded; real verification required before any production scale-up). The architecture must not preclude it.
- **Promotion stays a separate gated step; discovery != capture.**

## 3. Decisive criterion (the invariant the architecture must protect)

**Isolate the ToS-risky, high-lock-in, replaceable live-access layer from the
safe, durable, no-live-testable core (slices 1+2), joined by a NARROW
FAIL-CLOSED boundary** — so the risky access runtime can change or be killed
without touching the proven core, and the core stays no-live-testable.
Operational test: deleting the live layer leaves slices 1+2 green and fully
usable.

## 4. Option ledger + comparison

- **AO-1 — Thin live "adapter" → existing core.** A small live-access satellite (attended driver + presence/cap/no-bypass guards) produces a record that flows through a fail-closed boundary into the EXISTING `CandidateRow`/frontier types. Max reuse + isolation. **Most repo-native** (mirrors the reddit `register.py` "build → `to_dict()` → `validate_*`" seam). **Selected as the build.**
- **AO-2 — Separate parallel live signal pipeline.** New agnostic capture subsystem (RawSignal → typed → gated) converging with slices 1+2 only at promotion. More general; more new surface + lock-in; duplicates the rails (violates the spine's import-don't-duplicate rule). Converging "only at promotion" also lets raw signal travel further before default-deny bites. **Reserved for later, not built.**
- **AO-3 — Extend existing modules in place.** Live methods/fields on `CandidateRow`/`FrontierNode`. Minimal new structure but **couples the ToS-risky concern into the proven core whose key-allowlist IS the safety boundary** — every live field added widens the trusted allowlist. **Rejected** (violates the decisive criterion; highest, near-irreversible lock-in).
- **AO-4 — Hybrid: AO-1 now, generality-ready contract.** AO-1's reuse+isolation, with the new record named/shaped source-agnostically so an AO-2-style subsystem could later sit behind the same seam. **Selected as the stance**, but ONLY as "AO-1 with honest enum naming" — not a second abstraction layer.
- **AO-5 — Invert the dependency / validator-as-only-door (raised by adversarial lane).** Extract the fail-closed decision into a standalone policy module both sides depend on, so the rail is the only way to mint a row. **Principle adopted, structure deferred:** the "rail is the only mint-path" invariant is carried into slice 3b; a standalone policy module now is over-build (near-foreign to this codebase).

## 5. Recommended target: AO-4-as-AO-1, with two refinements

A thin, isolated **live-adapter satellite** (`capture_spine/linkedin_live_adapter/`)
that imports the core and never the reverse, feeds the existing types through the
existing validators, and is deletable without touching slices 1+2. With two
refinements the review lanes forced:

**Refinement A — Agnosticism is named-fields, not a free-form bag.** "Point at
any signal" = open input **enum axes** + the existing **closed output allowlist**
(`fields(...)`) + forbidden-field walk. **No `dict[str, Any]` payload** in or
before the core. New signal types arrive as *new named, separately-walked
fields*, not an untyped buffer. Rationale: an opaque bag is simultaneously the
over-capture smuggling surface and the read-time-minimization hole.

**Refinement B — Live posture = validated predicates, not enum labels.**
Presence-attested / no-bypass / attended-mode / caps are modeled as attestation
fields the validator **hard-fails on** — reusing the proven `execution_authorized
must be False` technique already in `NextRunEnvelope`. (Today the D5
`owner_present_attended_automation` MethodMode is just an enum string the closed-enum
validator accepts; presence/cap/no-bypass have zero enforcement representation in
the core.)

## 6. Adversarial findings already surfaced (the design must answer these)

These were found by the internal adversarial lane; the design addresses or
explicitly defers each. The reviewer should attack whether the resolution holds.

1. **Validators are post-hoc assertions over a producer-built dict, not a gate.** `validate_candidate_row` etc. consume a `Mapping` the caller already built; an adapter could construct a record, skip the validator, and call `to_dict()` directly. → **Resolution (deferred to slice 3b):** the *mint-path invariant* — make the validator the only door to obtain a row, with a test proving the raw constructor is unreachable from the adapter. NOT solved by slice 3a alone.
2. **All rails are output-side; read-time/acquisition minimization is unowned.** Nothing constrains what the adapter READS and buffers. An adapter could fetch a full profile + follower list, keep them in memory, emit one allowed field, and produce a clean record. → **Resolution (deferred to slice 3c, runtime):** a recorded-tape test asserting on *retained intermediate state*, named as a hard graduation requirement. Cannot be tested without a runtime.
3. **Fake-success: green no-live tests != live-layer compliance.** The validators only inspect dicts the test constructs; they never observe adapter read/keep behavior. "54 tests green" must NOT be read as "live layer safe." → **Resolution:** explicit honesty boundary in code + docs; a no-live test proves the rails reject bad rows, not that the adapter only produced good rows.

## 7. Core / satellite boundary + invariants

- **Core (untouched, durable, no-live-testable):** `linkedin_lane`, `linkedin_graph_frontier`. Gains NO live/ToS fields.
- **Satellite (isolated, replaceable, ToS-risky):** `linkedin_live_adapter/` — one-way import; killability is the operational test.

Invariants later work must preserve:
1. One-way import (core never imports adapter).
2. Core schemas/validators never gain live/ToS concepts (cookies/session/proxy/presence stay forbidden in core; the forbidden-field walk already rejects them).
3. No free-form `dict[str, Any]` before the rails; agnosticism via named fields + enum axes + closed allowlist.
4. Live posture modeled as validated predicates with failing tests, not enum labels.
5. [slice 3b+] The rail is the only mint-path (validator-as-only-door).
6. [slice 3c+] Read-time minimization (recorded-tape test on retained state).

## 8. Slice sequence (smallest-complete first; each its own buildable increment)

- **Slice 3a — "Live Access Envelope" contract, NO runtime.** A frozen `LiveAccessEnvelope` dataclass + `validate_live_access_envelope` + negatives-must-raise tests, in `linkedin_live_adapter/`. Fields name the *posture* (run_id, attended `method_mode`, `owner_presence_attested: bool`, `entitlement_gate_bypass: bool` (must be False), caps, stop_condition, `non_claims`). Validator imports + runs `assert_no_forbidden_output_fields`; key-allowlist via `fields(...)`; hard-fails bypass=True / presence=False / any non-attended mode; uses slice-2's *negated* non_claims check (slice-1 F4 positive-claim form is the logged-weak one). Mirrors how slices 1+2 shipped: contract + fail-closed validator, zero live risk, zero core change.
- **Slice 3b — observation → CandidateRow lowering + mint-path invariant.** The named-field projection from a live observation into the existing types; the validator-as-only-door enforcement.
- **Slice 3c+ — live driver/runtime.** Separately authorized, behind the legal/ToS hard graduation-gate, requiring the read-time minimization guarantee.

## 9. Rejected / deferred + what would change the recommendation

- **Rejected:** AO-3 (extend in place); foreign abstractions (`Protocol`/registry/`SignalSource` — zero precedent in `capture_spine`).
- **Reserved:** AO-2 parallel pipeline (only when a real second signal source exists).
- **What would change it:** a second live signal source already on the near-term roadmap (pulls AO-2 forward); evidence the core validators cannot gate a load-bearing live-only invariant (would need a small additive adapter validator, still isolated); the open #3 "anonymized-aggregate bottom-level signal" product question resolving toward individual-level aggregation (needs its own privacy-design pass before the projection map is frozen).

## 10. Open owner decisions (this artifact seeks sign-off on)

1. Approve the target (isolated thin adapter; named-field agnosticism; validated-predicate posture; runtime deferred)?
2. Accept the agnosticism tradeoff: "extract any signal" costs a new named field per new signal type, not a free-form catch-all (safer + repo-native, slightly less plug-and-play)?

## 11. Non-claims

This is a planning recommendation only. Not implementation, not a route, not
validation, not readiness, not promotion/capture, not legal/ToS clearance, not a
live runner. No code exists for the live layer. The legal/ToS safety of
owner-present autonomous access is unverified and deferred to a hard
graduation-gate.
