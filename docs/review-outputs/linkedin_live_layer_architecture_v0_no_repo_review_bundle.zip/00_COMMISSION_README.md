# Commission — Cross-Vendor Adversarial Artifact Review (no-repo, advisory findings-only)

## What this is
You are commissioned as a **de-correlated, different-vendor adversarial reviewer**
of one planning artifact: a **target architecture recommendation** for the "live"
layer of the Orca LinkedIn discovery lane. You have **no repo access**; everything
you need is in this bundle. Your output is **advisory findings only** — you do
NOT propose or apply a diff (no repo). The commissioning home model adjudicates
what is kept.

## Who-constraint (de-correlation)
- **authored_by:** `claude-opus-4.x` (the home model that wrote the target and will adjudicate your findings).
- **reviewed_by:** YOU — must be a **different vendor/family** than the author (e.g. a GPT / Gemini / other non-Anthropic model). State your model+vendor in your output.
- **de_correlation_bar:** `cross_vendor_discovery`. The point of this pass is to catch blind spots a same-family self-review would share. If you are an Anthropic-family model, STOP and report the de-correlation is unsatisfied.

## Your method
Follow `02_PORTABLE_METHOD.md` exactly (the PORTABLE METHOD block). It is the
self-contained adversarial-artifact-review method; you cannot invoke Orca skills,
so the embedded method IS your procedure. Reasoning-before-findings is required.

## The target
- `01_REVIEW_TARGET_live_layer_architecture_v0.md` — the artifact under review. (Confirm your copy against the SHA256 the commissioner gives you out-of-band; if you cannot, proceed advisory-only and say so.)

## Authority the target must conform to (in `authority/`)
- `AGENTS.md` — the Orca kernel. **Conformance to the Smallest Complete Intervention rule is part of your review** — flag scope inflation (speculative additions) AND underfix (symptom-only) against the target's actual purpose.
- `linkedin_lane_architecture_v0.md` — the committed lane architecture: Hard Stops, Non-Claims, person public-actor basis, the D5 attended-automation variant.
- `linkedin_lane_index_v0.md` — the entry map and "hard rails."

## Grounding source (in `source/`) — so you can check the target's claims against real code
- `linkedin_lane/` + `linkedin_graph_frontier/` — the existing no-live slices 1+2 (frozen dataclass + module-level `validate_*` + `assert_no_forbidden_output_fields` walk + key-allowlist). The target claims to REUSE these and to leave them untouched — verify that's coherent.
- `tests/` — the slice 1+2 unit tests (the "54 tests green" + fail-closed test style). The target makes a load-bearing claim that **green no-live tests do NOT prove live-layer compliance** — check it against what these tests actually assert.
- `pattern/reddit_graph_frontier_register.py` — the sibling builder the target cites as the house "build → to_dict() → validate_*" seam.

## What to attack hardest (decision-relevant)
1. Does the **isolation invariant** (delete-the-adapter-and-the-core-still-works) actually hold under the recommended shape, or does the seam leak the live/ToS concern into the durable core?
2. Is **"named-field agnosticism, no opaque bag"** a real resolution of the generality-vs-rails tension, or does it quietly break the owner's "extract any signal we want" requirement (each new signal needs a new named field + allowlist widening)?
3. Are the three **already-surfaced adversarial findings** (validators-are-assertions-not-a-gate; output-only rails / no read-time minimization; green-tests != live-safe) **adequately resolved or honestly deferred** — or is a deferral hiding a hole that should block slice 3a?
4. Is the **slice 3a / 3b / 3c sequencing** genuinely smallest-complete, or does 3a smuggle in lock-in / premature runtime gravity?
5. **Overclaims / scope:** any readiness/validation/safety claim the evidence doesn't support; any scope inflation vs the Smallest Complete Intervention rule.

## Boundary
Findings are **decision input only** — not approval, validation, readiness, or
mandatory remediation. The home model adjudicates each finding as a claim
(accept/modify/reject) and a bounded same-vendor recheck confirms closure before
anything is kept. Use `critical`/`major`/`minor` as priority labels only.

## Bundle map
```
00_COMMISSION_README.md      <- this file
01_REVIEW_TARGET_*.md        <- the artifact under review
02_PORTABLE_METHOD.md        <- your method (follow it)
authority/                   <- the rules the target must conform to (kernel + committed lane authority)
source/                      <- grounding harness (slices 1+2 + tests + pattern sibling)
```
