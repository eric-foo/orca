# No-Repo Delegated Review Commission — LinkedIn Lane No-Live Harness, Slice 1 (v0)

You are a **DE-CORRELATED reviewer** (a **DIFFERENT vendor/family from the author**, Anthropic/Claude, an Opus-class model) with **NO repository access**. Everything you need is in this bundle. Review only from these files; do not assume repo access.

## De-correlation receipt (state this first, before any finding)
- Author / home model family: **Anthropic / Claude, Opus-class**.
- You must be a **different vendor/family and non-Opus**. **State your model vendor/family** in your output.
- If you are the same family as the author, **STOP** — you are not de-correlated and cannot serve this commission.

## Your method
- Use `context/portable_adversarial_review_method.md` — follow **only the delimited `PORTABLE METHOD` block** (your stance, the reasoning-before-findings order, severity meaning, and the review-use boundary). The header/footer outside that block are repository metadata.
- This is a **no-repo, advisory-only** review: the authoring environment's formal review tooling is **not available to you**, which bounds your result to **advisory critique, not a formal verdict** — state that.
- **One commission-specific override** of the portable method's output contract: because this is a review-**and-patch** commission for **code**, you MAY return *advisory* proposed edits (see Return). The portable method's "no executor-ready patch steps" default is relaxed to "advisory proposed edits the author applies + adjudicates." You still do not and cannot touch a working tree.

## Target (review THIS; bounded patch scope)
- `target/capture_spine/linkedin_lane/models.py` — frozen-dataclass models: `RunEnvelope`, `CandidateRow`, `VisibleInfluenceNumbers`, the `StrEnum`s, `LinkedInLaneError`, the `LINKEDIN_LANE_*_SCHEMA_VERSION` constants, `DEFAULT_LINKEDIN_LANE_NON_CLAIMS`, `to_dict`/`_enum_values`.
- `target/capture_spine/linkedin_lane/validation.py` — module-level validators: `FORBIDDEN_OUTPUT_FIELDS`, `assert_no_forbidden_output_fields`, the secret-value patterns, `validate_run_envelope`, `validate_candidate_row`, `_validate_person_row`.
- `target/capture_spine/linkedin_lane/__init__.py` — public exports.
- `target/tests/test_linkedin_lane.py` — its tests (**19/19 passing** in the author's repo).
- **Attachment integrity:** `TARGET_SHA256.txt` lists each target file's SHA256. Recompute and confirm they match; if you cannot confirm, proceed advisory-only and say so.

## What this is — scope frame (do NOT flag deferred scope as a gap)
- This is **SLICE 1 ONLY**: `RunEnvelope` + `CandidateRow` + their validators + tests. The **Graph Frontier register, `PromotionReceipt`, the live runner, supervised-browser-assist execution, promotion/capture execution, and persistence are DEFERRED to later slices BY DESIGN.** Do **not** flag their absence as an omission. **Do** flag if slice 1 itself overreaches into them (scope inflation).
- **Claim boundary:** the author claims ONLY "this module + its own tests pass." NOT lane validation/readiness, NOT a live runner, NOT promotion/capture, NOT commit.

## Contract to check it against (authority — the target must conform)
- `context/data_capture_spine_linkedin_discovery_planning_lane_architecture_v0.md` — the authoritative **Candidate Row Schema + Hard Stops**. This is the **field source-of-truth**: `models.py` is meant to be a mechanical translation of the Candidate Row Schema.
- `context/linkedin_lane_operator_pilot_plan_v0.md` — the review-cleared **operator pilot plan**. This is the **acceptance-gate source-of-truth**: `validation.py` is meant to translate the pilot's acceptance gate into raising validators.
- `context/AGENTS_kernel.md` — the authoring environment's foundational behavior + scope-discipline doctrine. Check conformance to the **Agent Behavior Kernel** and especially the **Smallest Complete Intervention** rule (complete but not inflated; no fake-success paths). NOTE: this file references overlay files under `.agents/workflow-overlay/` that are **not** in this bundle and are **out of scope** — check against the kernel text you have, not the referenced files.

## Referenced pattern it REUSES (verify faithful reuse; READ-ONLY — flag, do not patch)
- `context/reddit_candidate_intake_models.py` + `_validation.py` + `_init.py` — the `capture_spine` sibling whose pattern this lane deliberately mirrors: frozen `@dataclass` + `StrEnum` + a custom `*Error(ValueError)` + module-level `validate_*` + a recursive `assert_no_forbidden_output_fields` walk over a **lane-specific** `FORBIDDEN_OUTPUT_FIELDS` set + secret-value patterns + `*_or_none` honesty fields + `to_dict`/`_enum_values`. The forbidden-field walk is **deliberately duplicated** into `linkedin_lane` (not imported) because the field **sets differ**. Verify the mirror is faithful and the duplication is justified; do not propose collapsing them unless you can show the sets are actually identical.

## Adversarially check (be maximally adversarial within the bounded target)
**(a) Faithful to architecture + pilot.** Does `CandidateRow`'s field set match the Candidate Row Schema? Do the `StrEnum` vocabularies match the architecture's candidate classes / entity types / method modes / source surfaces / stop reasons? Is the person-row gate (concrete **org-chart-independent public-actor basis** + `privacy_sensitivity` in the person set + `minimization_rule` + `person_data_minimized` in {yes,no}) faithful to the Hard Stops?

**(b) Validators REAL — fake-success guard (load-bearing).** Do the negatives actually **raise `LinkedInLaneError`**, or is any test green-but-hollow? Cover: forbidden output field (top-level **and** nested in a dict/list), person row missing basis, person row wrong privacy, person row `person_data_minimized=not_applicable`, `allowed_downstream_use != planning_only`, `capture_unit_intake_status != candidate_or_scouting`, `promotion_required` not `True`, any of the four retained flags `True`, a secret-like value, and the envelope caps / empty-classes / empty-theme cases. **Is there any bad input that SHOULD raise but slips through?**

**(c) Forbidden-field precision.** `FORBIDDEN_OUTPUT_FIELDS` is matched by **exact lowercased key**. Confirm this is right: the allowed visible-influence fields (`follower_count_or_none`, `connection_count_band_or_none`, `subscriber_count_or_none`, `engagement_count_or_none`) must **NOT** trip the walk, while follower/connection/commenter **lists + graphs**, contact fields, profile body, post content, and downstream-stage keys **must**. Is the set complete vs the architecture Hard Stops? Any banned concept reachable under a key **not** in the set (a bypass)? Any over-broad exact key that would reject a legitimate field?

**(d) Privacy / minimization / hard-stop fidelity.** Do `DEFAULT_LINKEDIN_LANE_NON_CLAIMS` and the retained-flags-false invariant actually encode the architecture's Hard Stops (no live access; no contact acquisition / lead lists; no follower/connection/commenter graph capture; no profile body / content capture; no `SourceCapturePacket` output; no Data Capture handoff; no Outreach execution; no no-entitlement gate bypass)? Do the secret-value patterns (pem private key, bearer token, credentialed-URL userinfo, set-cookie) anchor on **unambiguous markers** (no entropy false-positives on candidate vocabulary like names, locators, coarse counts)?

**(e) Boundary leaks / overclaim.** Does any field or default let a candidate row imply promotion, capture, or downstream binding (it must stay `planning_only` / `candidate_or_scouting` / `promotion_required=True`)? Does `to_dict`/`_enum_values` round-trip cleanly and serialize enums to their **string** values, so `validate_candidate_row` (which reads the dict) sees plain strings rather than enum objects?

**(f) Scope discipline (AGENTS kernel).** Is slice 1 the **smallest complete** intervention — complete (a durable validator, not symptom-only or fragile) yet not inflated (no slice-2 frontier/promotion, no speculative abstraction, no unrelated cleanup)? Flag **both** overreach and underfix against the stated slice-1 purpose.

**(g) Evolution-safety.** Additive `StrEnum` growth, frozen-dataclass immutability, and the exact-match forbidden set: will adding a new allowed `*_count_or_none` field silently break, or a new banned concept silently slip through, on future growth?

## Return (NO repo access — you CANNOT edit the working tree)
- Lead with the portable method's `review_summary` block, then findings in **code-review schema**, ordered `critical` → `major` → `minor`.
- For each finding: `severity` (priority label only — no approval/readiness/validation authority), `location` (file + symbol/line), `issue`, `evidence` (cite the target section **and** the conflicting authority excerpt by file name + section/line — neutral in tone, decision-sufficient in substance), `impact`, `minimum_closure_condition` (the end state, not how-to), `next_authorized_action`.
- For accepted findings you **may** return **advisory** proposed edits — a unified diff or exact replacement blocks against the `target/` files **only**. These are **claims the author applies + adjudicates** in the real repo; your diff is not applied by you and is not a premise.
- Bounded patch scope = `target/capture_spine/linkedin_lane/*` and `target/tests/*` **only**. `context/` is read-only reference — flag issues there, do not propose edits to it.
- Design-level problem (the architecture/pilot themselves are wrong, or the dataclass pattern is unfit) → return **`NEEDS_ARCHITECTURE_PASS`** (findings only, no proposed edits); do not patch over a broken design.
- If you find no material issues, say so and list residual risks / test gaps.

## Boundary
This is a portable (no-repo) delegated **advisory** review under a **provisional** Orca convention. Your findings are **decision input only** — not approval, validation, readiness, product proof, mandatory remediation, or executor-ready instructions. The author (CA) adjudicates what is kept. After the author applies accepted edits, a **separate bounded post-patch re-review** (closure-of-findings + any new blocker/major in the touched delta) is **required before anything is kept**. Nothing here is committed; nothing downstream is bound unless a separate authorized decision accepts it.
