# REQUIRED Post-Patch Re-Review Commission — LinkedIn Lane Operator Pilot Plan v0 (no_repo, advisory)

This is the **mandatory de-correlated post-patch re-review** required by the
`no_repo` mode of `.agents/workflow-overlay/delegated-review-patch.md`. In
`no_repo` mode the first delegate reviewed but the **CA (an Opus-class author)
applied the patch**, so patch-time de-correlation must be restored by a second
different-family pass **before anything is kept**. Advisory only — not
validation, approval, readiness, or a binding verdict.

## Lane Binding

```yaml
overlay_status: provisional_opt_in
operating_contract_pointer: .agents/workflow-overlay/delegated-review-patch.md
review_lane: artifact (adversarial-artifact-review)
access: no_repo                     # return FINDINGS, not a diff
mode: post_patch_recheck            # bounded blast-radius: closure-of-findings + NEW blocker/major in the touched delta only
freshness_gate: PASS                # portable-method derived_from pins hash-matched live at bundle time (unchanged)
```

## Actor / Model-Family Receipt (de-correlation)

```yaml
author_home_model_family: Anthropic Claude (Opus-class)   # authored the plan AND applied the patch AND adjudicates
controller_delegate_model_family: <operator selects>      # MUST be non-Opus, different family. PREFER a FRESH delegate (not the first reviewer) to avoid self-confirmation.
current_receiving_actor_role: controller
dispatch_mode: external-controller-courier
de_correlation_status: satisfied_iff_delegate_is_non_opus_different_family
```

## Target (PATCHED — new hash)

- `target/linkedin_lane_operator_pilot_plan_v0.md`
- **SHA256 (confirm before reviewing):** `aa6b9f8d051b1baeb8208577c180c9b747b382b0ae15561ad12b848b6ad71aa7`
- (The pre-patch version reviewed by the first delegate hashed `057ba0f3…cb850da0`.)

## Your bounded task (do NOT re-review the whole document)

Per the smallest-complete bounded blast-radius rule:

1. **Closure check** — for each of the 3 prior findings below, decide `closed` /
   `partially_closed` / `not_closed` against its `minimum_closure_condition`,
   using the patched target + the `authority/` excerpts.
2. **Delta scan** — inspect **only the touched spots** (the 5 edits below) for
   any **new `critical`/`major`** issue the patch introduced (e.g. a new
   contradiction with `authority/01`, a new over/under-reach vs the Smallest
   Complete Intervention rule in `authority/02`).
3. Do **not** raise new `minor`/structural findings outside the touched scope;
   do **not** retarget or widen. Return findings, not a diff.

Escalation: if closing a finding would require changing `authority/01` (the
architecture), say `NEEDS_ARCHITECTURE_PASS` — do not treat it as closed.

## Prior findings + CA adjudication + exact patch applied

**The CA accepted all 3 findings.** Verify the patches actually close them.

### Finding 1 (MAJOR) — person-row basis under-specified vs architecture
- **Was:** the plan required only "a concrete `senior_role_or_public_actor_basis_or_none` that stands outside the employer org chart"; the architecture (Candidate Classes) requires a **concrete pointer drawn from named allowed categories** and **excludes** org-chart presence, mentions/tags, routine employer-feed posts, and commenter/follower/connection status.
- **minimum_closure_condition:** the pilot's Discovery guardrail AND Acceptance Gate require each person row to carry a concrete qualifying pointer from the architecture's allowed categories and reject excluded bases.
- **Patch (Discovery guardrail):** now requires the basis "with a concrete pointer drawn from the architecture's allowed bases" — a named public appearance under the person's own name; an official spokesperson/founder/executive/named-decision-maker role for the theme; or an owned public professional/creator presence — and states "Org-chart presence, mentions or tags by others, routine employer-feed posts, and commenter/follower/connection status are NOT a qualifying basis."
- **Patch (Acceptance Gate):** the person-row condition now reads "with a concrete qualifying pointer from the architecture's allowed source categories (and none drawn from an excluded basis — org chart, mention/tag, routine post, commenter/follower/connection)."

### Finding 2 (MAJOR) — closeout could imply same-artifact promotion
- **Was:** the closeout field `operator_decision.promote_candidate_now: yes | no | deferred` could be machine-read as a promotion, while the architecture requires a **separate promotion receipt**.
- **minimum_closure_condition:** the closeout records only whether to OPEN the separate promotion gate; actual promotion stays invalid unless the separate receipt exists.
- **Patch (closeout field):** renamed to `recommend_open_promotion_gate: yes | no | deferred   # a planning recommendation ONLY — never promotion itself`.
- **Patch (trailing sentence):** now "The operator decision is a planning decision only — it records whether to *open* the separate promotion gate, never a promotion. Actual promotion is invalid unless the separate authority-required promotion receipt (§Promotion Decision) exists."

### Finding 3 (MINOR) — local JSON/Markdown output storage ambiguity
- **Was:** "local JSON/Markdown written under the lane's planning output" could be misread as authorizing durable people-dataset storage, which the architecture hard-stops.
- **minimum_closure_condition:** the output is clearly a bounded local planning artifact, not a datastore/dataset/runtime storage.
- **Patch (Outputs):** now "a bounded, operator-held local planning artifact (JSON/Markdown) holding this run's rows / register / closeout — **not** a database, reusable people dataset, durable datastore, scheduler, dashboard, or product/runtime storage."

## Method, authority, output

Follow `method/portable_adversarial_artifact_review_method.md`. Conform-check
against `authority/01_accepted_linkedin_lane_architecture.md` (controlling) and
`authority/02_agents_kernel.md` (Smallest Complete Intervention). Return a
`review_summary` + a per-finding closure verdict + any new blocker/major in the
delta, citing the patched-target section and the authority excerpt. No
executor-ready patch steps.

## Adjudication + keep gate

The CA adjudicates your closure verdicts. The patch is **KEPT only if** every
finding is `closed` and the delta scan surfaces no open `critical`/`major`.
Anything `not_closed` or any new blocker routes back to a further CA patch (and
another re-review) or, if design-level, an architecture pass.

## Non-Claims

Provisional convention. Not validation, readiness, formal review authority, a
bound/mandatory/machine-routable lane, runtime model routing, or patch
authorization beyond the CA's bounded application. De-correlation is a
who-constraint, not a model-quality claim.
