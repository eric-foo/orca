# Delegated Review-And-Patch Commission -- LinkedIn Lane slice 3b-2 (projection + mint-path)

NO-REPO bundle. You (the reviewer) have NO repository access: reconstruct the
package from /source, read /method, review against this commission. Advisory
cross-vendor discovery review.

## Lane Binding
- review_lane: code (workflow-code-review)
- mode: base-subagent
- actor_model_family_receipt:
  - author_home_model_family: anthropic (claude-opus) -- authored the code under review
  - controller_model_family: openai (gpt-5.5) -- YOU; a different vendor (de-correlation satisfied)
  - current_receiving_actor_role: controller
  - dispatch_mode: external-controller-courier (no repo access)
  - de_correlation_status: satisfied (openai != anthropic)
- Review with fresh priors; do NOT assume the author's framing is correct.

## Target (the editable scope)
- PRIMARY: capture_spine/linkedin_live_adapter/projection.py -- project_observation_to_candidate_row
- tests: tests/unit/test_linkedin_live_adapter.py (the slice 3b-2 "projection" section)
- supporting context (READ-ONLY; flag if implicated, do NOT propose edits there): the other
  /source files -- the core CandidateRow + validate_candidate_row, the live-adapter models +
  validators, shared_validation.

## Why source-read-only review is insufficient
The mint-path and the posture binding are correctness/safety invariants. We want adversarial
attempts to BREAK them, plus a bounded patch for any real finding -- not a skim.

## What this code is
slice 3b-2 projects a minimized LiveObservation into a core CandidateRow. It is the MINT-PATH:
project_observation_to_candidate_row is intended to be the ONLY adapter door that emits a
candidate row, returning ONLY a validate_candidate_row-passing dict (build -> to_dict ->
validate, mirroring reddit_candidate_intake). It also BINDS the observation to a VALIDATED
LiveAccessEnvelope (matching live_access_id + run_id) and the RunEnvelope -- closing a prior
deferral (slice-3b F3: posture was an unchecked id reference, not a bound validated envelope).

## Review focus (attack these)
1. MINT-PATH: can any exported path return an UNvalidated or invalid CandidateRow dict? Is
   build->to_dict->validate airtight? Note the deliberate design: the projection passes
   enumerated fields through as STRINGS and lets validate_candidate_row be the single closed-enum
   gate (because validate_live_observation does NOT closed-enum-check minimization_rule /
   person_data_minimized). Verify validate_candidate_row truly rejects every bad enumerated value.
2. BINDING / F3: can an observation be projected against a NON-matching or UNvalidated access
   envelope / run envelope? Are the live_access_id + run_id equality checks complete (all three:
   observation == access_envelope == run_envelope)? Any ordering bug letting a bad record through
   before the bind/validate?
3. FIELD-MAP: are LiveAccessMode->MethodMode and entity_type->PrivacySensitivity correct and
   FAIL-CLOSED (unmapped -> raise, never a permissive default)? Is the person path
   (public_actor_strict + carried basis + person_data_minimized == "yes") correct against
   validate_candidate_row's person gate?
4. DECLARED-ENVELOPE BINDING: candidate_class in run_envelope.candidate_classes and
   observed_source_surface in run_envelope.source_surface_allowlist -- bypassable? Right checks?
5. MINIMIZATION / SMUGGLING: can over-captured content reach the candidate row via a carried
   free-text field, visible_influence_numbers, or source_locators? Is observed_location correctly
   DROPPED (not smuggled)? Any field that should be dropped but is carried?
6. FAKE-SUCCESS in tests: do the negatives actually fail bad input (each asserts the
   LinkedInLaneError .code)? Any green-but-hollow test? Missing attack case (esp. a path that
   should raise but the test would pass on a silent bypass)?

## Controller output contract
- Run the workflow-code-review lane method (see /method).
- Findings in that schema, with per-change source citations (file + line/section), neutral in
  tone, decision-sufficient in substance.
- A bounded unified diff (working tree) for accepted findings, touching ONLY projection.py + the
  test file. Anything off that scope: flag, do not patch.
- A verdict + residual-risk note.
- Escalation: if the mint-path/binding SHAPE itself is wrong (design-level), return
  NEEDS_ARCHITECTURE_PASS, do NOT patch, findings only.

## Adjudication
The home model (anthropic/claude-opus) adjudicates your diff/citations/verdict as CLAIMS, not
premises -- accept / modify / reject each against the citations and intent. Final keep authority
is the home model's; it may veto an individually-defensible change.

## How to run the tests (the only validation claim = "module + its tests pass")
Reconstruct /source preserving the paths in MANIFEST.md (capture_spine/ + tests/ as siblings),
set PYTHONPATH to that root, then:
  python -m pytest tests/unit/test_linkedin_live_adapter.py -q
At author time 103 tests pass (93 prior LinkedIn + 10 new project_* tests).

## Boundaries
Advisory cross-vendor discovery review. NOT approval / validation / readiness / live-runner /
commercial authorization. Harness claim boundary is "module + its tests pass" only. The live
runtime (browser/session/fetch) is slice 3c, behind a separate legal/ToS gate -- out of scope.
