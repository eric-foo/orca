# Commission — Cross-Vendor Adversarial CODE Review (no-repo, advisory findings-only)

## What this is
You are commissioned as a **de-correlated, different-vendor adversarial CODE
reviewer** of a **refactor** of the Orca LinkedIn discovery lane's validators:
the duplicated fail-closed validation helpers were extracted into one shared
module, and two long-standing drifts were reconciled. You have **no repo
access**; everything is in this bundle. Output is **advisory findings only** (no
diff). The home model adjudicates what is kept.

## Who-constraint (de-correlation)
- **authored_by:** `claude-opus-4.x` (wrote the refactor; will adjudicate your findings).
- **reviewed_by:** YOU — must be a **different vendor/family** (GPT / Gemini / other non-Anthropic). State your model+vendor. If Anthropic-family, STOP — de-correlation unsatisfied.
- **de_correlation_bar:** `cross_vendor_discovery`.

## What changed (so you can check behavior-preservation)
Before: slices 1, 2, and 3a each **re-implemented** the generic fail-closed
helpers (the non_claims check, excluded-person-basis markers, key-allowlist,
required-field check, etc.). They had **drifted**:
- slice-1's non_claims check was a **weaker substring** form — a positive `"live LinkedIn access"` satisfied the `"live"` hard-stop category (the "F4" weakness);
- the excluded-basis marker lists diverged: slice-2 carried `"routine employer"`; slice-1 did not.

After (this refactor):
- New single source of truth: `review_target/shared_validation.py` — the forbidden-output-field walk, key allowlist (`reject_unknown_keys`), `require_fields`, the **strong NEGATED** non_claims check (`validate_non_claims_categories` + `is_negated` + reversal markers), and the **superset** excluded-basis markers (`validate_public_actor_basis`).
- Slices 2 and 3a were retrofitted by **import-aliasing** the shared helpers to their existing local names — validator **bodies unchanged** (intended: behavior-preserving).
- Slice-1 was switched to the strong shared checks — **intended behavior changes:** positive non_claims now raise (F4 closed); a `"routine employer"` basis now raises.
- `linkedin_lane/__init__.py` re-exports `FORBIDDEN_OUTPUT_FIELDS` / `assert_no_forbidden_output_fields` from the new shared module (API stable).
- All 72 tests pass (70 prior + 2 new slice-1 negatives).

## Method
Code review. Follow `02_PORTABLE_METHOD.md` as the general adversarial procedure
AND apply code-review judgment (correctness + the fake-success/hollow-test check).

## The target (`review_target/`)
`shared_validation.py` (new) + the three retrofitted `*__validation.py` + `linkedin_lane__init__.py`. Tests in `tests/`. Record shapes for context in `authority/*__models.py`. Kernel in `authority/AGENTS.md` (Smallest Complete Intervention — conformance is part of the review).

## Attack hardest (decision-relevant)
1. **Behavior-preservation for slices 2/3a (committed + already cross-vendor-reviewed):** did the extraction *silently change* any slice-2 or slice-3a enforcement? Trace each retrofitted validator against the shared helpers — is the aliasing truly body-for-body equivalent, or did a default/argument differ?
2. **Slice-1's intended changes — correct AND complete?** Does the F4 fix (weak→strong negated) or the superset markers wrongly **reject a legitimate** slice-1 input (false positive), or still **let a bad one pass** (incomplete)?
3. **Reconciliation correctness:** is the shared marker set the true **superset** of the old slice-1 ∪ slice-2 lists (no marker dropped)? Is the non_claims category set unchanged? Any silent loss.
4. **New bypass/gap from centralization:** does any slice now *skip* a check it used to run (e.g., an order change, a missing call, a record that no longer reaches a helper)?
5. **Import direction / cycle:** `shared_validation` must import only `LinkedInLaneError`; confirm no slice→shared→slice cycle, and that the `__init__` re-export is correct.
6. **Hollow tests:** do the new slice-1 negatives actually prove `validate_*` RAISES on the targeted case (not constructor failure / not green-but-empty)?
7. **Scope:** over-reach (sharing what shouldn't be shared) or under-reach (leftover drift) vs Smallest Complete; any overclaim beyond "modules + tests pass."

## Boundary
Findings are decision input only — not approval, validation, readiness, or mandatory remediation. The home model adjudicates each as a claim; a bounded same-vendor recheck confirms closure before keep. `critical`/`major`/`minor` are priority labels only.

## Bundle map
```
00_COMMISSION_README.md   <- this file
02_PORTABLE_METHOD.md     <- general adversarial procedure
review_target/            <- shared_validation.py + 3 retrofitted validators + the __init__
tests/                    <- the 3 test files (verify coverage + non-hollow)
authority/                <- kernel + the record-shape models (context)
```
