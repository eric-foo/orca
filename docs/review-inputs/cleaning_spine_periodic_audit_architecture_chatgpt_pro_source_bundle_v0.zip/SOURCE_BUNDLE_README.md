# Cleaning Spine Periodic Audit Architecture Source Bundle v0

Use this ZIP with ChatGPT Pro to answer the prompt in:

docs/prompts/deep-thinking/cleaning_spine_periodic_audit_architecture_chatgpt_pro_prompt_v0.md

Recommended read order:

1. source_bundle_manifest.json
2. docs/prompts/deep-thinking/cleaning_spine_periodic_audit_architecture_chatgpt_pro_prompt_v0.md
3. orca-harness/runners/run_capture_ecr_cleaning_smoke.py
4. orca-harness/tests/unit/test_capture_ecr_cleaning_smoke_runner.py
5. orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/stitched/smoke_summary.json
6. orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/raw_cleaned_review_packet/packet_manifest.json
7. docs/review-outputs/adversarial-artifact-reviews/ig_cleaning_raw_vs_cleaned_adversarial_artifact_review_v0.md

Optional evidence for spot checks:

- orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/stitched/cleaning_packet.json
- orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/stitched/ecr_source_side_receipts.json
- orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/raw_cleaned_review_packet/raw_cleaned_pairs.json
- orca-harness/_test_runs/ig_cleaning_spine_stage1_20260621/raw_cleaned_review_packet/review_prompt.md
- docs/prompts/reviews/ig_cleaning_raw_vs_cleaned_adversarial_artifact_review_prompt_v0.md

Boundary: this bundle is for architecture advice only. It is not live capture, production validation, full Orca E2E readiness, Judgment scoring, or product proof.
