# Independent Review Prompt: IG Raw vs Cleaned

Read `packet_manifest.json` and `raw_cleaned_pairs.json` in this directory. Do not edit files.

For each sampled or all pairs, compare:
- `raw.value_at_json_pointer` and `raw.parent_context_excerpt`
- `projection_row.metric`, `projection_row.posture`, `projection_row.value`, `projection_row.reason`, and source-visible fields
- `cleaned_handle.raw_anchor`, `projection_ref`, `ecr_ref`, warnings, residuals, and raw-pull triggers

Return:
1. Verdict: `bounded_raw_to_cleaned_trace_supported`, `partially_supported`, or `not_supported`.
2. Findings with severity, source_label, handle_id, raw evidence, cleaned/projection evidence, and why it matters.
3. Whether Cleaning overcleaned meaning, undercleaned traceability, lost anchors, or introduced Judgment semantics.
4. A plain-language statement of exactly what Cleaning cleaned and did not clean.

Constraints:
- Do not treat ECR residuals as failure by themselves.
- Do not infer demand, credibility, salience, independence, product quality, or actionability.
- A supported result means the cleaned handle/projection row can be mechanically derived from the raw anchor and packet metadata while preserving stated residuals.
